import { Component, useState, type ErrorInfo, type ReactNode } from 'react';
import Shell from './components/Shell';
import { StoreProvider, useStore } from './store';
import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import PosPage from './pages/PosPage';
import OrdersPage from './pages/OrdersPage';
import KitchenPage from './pages/KitchenPage';
import TablesPage from './pages/TablesPage';
import ReservationsPage from './pages/ReservationsPage';
import CustomersPage from './pages/CustomersPage';
import MenuPage from './pages/MenuPage';
import CategoriesPage from './pages/CategoriesPage';
import InventoryPage from './pages/InventoryPage';
import RecipesPage from './pages/RecipesPage';
import SuppliersPage from './pages/SuppliersPage';
import PurchasesPage from './pages/PurchasesPage';
import DeliveryPage from './pages/DeliveryPage';
import ExpensesPage from './pages/ExpensesPage';
import EmployeesPage from './pages/EmployeesPage';
import AttendancePage from './pages/AttendancePage';
import PayrollPage from './pages/PayrollPage';
import AccountingPage from './pages/AccountingPage';
import ReportsPage from './pages/ReportsPage';
import ProfitPage from './pages/ProfitPage';
import DuesPage from './pages/DuesPage';
import DiscountsPage from './pages/DiscountsPage';
import QrMenuPage from './pages/QrMenuPage';
import SettingsPage from './pages/SettingsPage';
import RolesPage from './pages/RolesPage';
import PublicMenuPage from './pages/PublicMenuPage';
import { rolePermissions } from './lib/pos';

class ErrorBoundary extends Component<{ children: ReactNode }, { error: Error | null }> {
  state = { error: null as Error | null };

  static getDerivedStateFromError(error: Error) {
    return { error };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error('Screen crashed', error, info.componentStack);
  }

  render() {
    if (!this.state.error) return this.props.children;
    return (
      <div className="grid min-h-screen place-items-center bg-page px-6 text-center text-ink">
        <div className="max-w-sm">
          <div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-ink font-serif text-xl text-white">!</div>
          <h1 className="mt-4 font-serif text-[22px]">Something went wrong on this screen</h1>
          <p className="mt-1.5 text-[12.5px] text-mute2">{this.state.error.message}</p>
          <button onClick={() => window.location.reload()} className="mt-5 rounded-xl bg-ink px-5 py-2.5 text-[12.5px] font-semibold text-white">
            Reload
          </button>
        </div>
      </div>
    );
  }
}

const isPublicMenuRoute = () => {
  const path = window.location.pathname.replace(/\/+$/, '');
  const params = new URLSearchParams(window.location.search);
  return path.endsWith('/menu') || params.get('view') === 'menu' || window.location.hash.startsWith('#/menu');
};

function Console() {
  const { user, ready } = useStore();
  const [view, setView] = useState('dashboard');
  const isPublicMenu = isPublicMenuRoute();

  if (isPublicMenu) return <PublicMenuPage />;

  if (!ready) {
    return (
      <div className="grid min-h-screen place-items-center bg-page">
        <div className="flex flex-col items-center gap-3">
          <div className="h-10 w-10 animate-spin rounded-full border-2 border-accent/30 border-t-[#e7b943]" />
          <div className="text-[11px] uppercase tracking-[.24em] text-mute2">Loading branch data</div>
        </div>
      </div>
    );
  }

  if (!user) return <LoginPage />;

  const pages: Record<string, () => JSX.Element> = {
    dashboard: () => <DashboardPage onNavigate={setView} />,
    pos: () => <PosPage onNavigate={setView} />,
    orders: () => <OrdersPage />,
    kitchen: () => <KitchenPage />,
    tables: () => <TablesPage />,
    reservations: () => <ReservationsPage />,
    customers: () => <CustomersPage />,
    menu: () => <MenuPage />,
    categories: () => <CategoriesPage />,
    inventory: () => <InventoryPage />,
    recipes: () => <RecipesPage />,
    suppliers: () => <SuppliersPage />,
    purchases: () => <PurchasesPage />,
    delivery: () => <DeliveryPage />,
    expenses: () => <ExpensesPage />,
    employees: () => <EmployeesPage />,
    attendance: () => <AttendancePage />,
    payroll: () => <PayrollPage />,
    accounting: () => <AccountingPage />,
    reports: () => <ReportsPage />,
    profit: () => <ProfitPage />,
    dues: () => <DuesPage />,
    discounts: () => <DiscountsPage />,
    qr: () => <QrMenuPage />,
    settings: () => <SettingsPage />,
    roles: () => <RolesPage onNavigate={setView} />
  };

  const scopes = rolePermissions.find(entry => entry.role === user.role)?.scopes ?? Object.keys(pages);
  const activeView = scopes.includes(view) && pages[view] ? view : 'dashboard';

  return (
    <Shell view={activeView} onNavigate={setView}>
      {pages[activeView]()}
    </Shell>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <StoreProvider>
        <Console />
      </StoreProvider>
    </ErrorBoundary>
  );
}
