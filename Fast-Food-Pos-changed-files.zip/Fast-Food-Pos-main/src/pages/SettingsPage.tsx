import { useState } from 'react';
import { Building2, Database, Percent, Save, Server, Store } from 'lucide-react';
import { useStore } from '../store';
import { Badge, Button, inputCls, Labeled, PageHeader, panel, Select, textareaCls } from '../components/ui';
import type { RestaurantSettings } from '../types';


const regionPresets: { value: string; label: string; currency: string; taxLabel: string; taxRate: number }[] = [
  { value: 'custom', label: 'Custom', currency: '', taxLabel: '', taxRate: 0 },
  { value: 'usd', label: 'United States · USD ($)', currency: '$', taxLabel: 'Sales tax', taxRate: 8 },
  { value: 'cad', label: 'Canada · CAD ($)', currency: 'CA$', taxLabel: 'GST/HST', taxRate: 5 },
  { value: 'gbp', label: 'United Kingdom · GBP (£)', currency: '£', taxLabel: 'VAT', taxRate: 20 },
  { value: 'eur', label: 'Eurozone · EUR (€)', currency: '€', taxLabel: 'VAT', taxRate: 20 },
  { value: 'aud', label: 'Australia · AUD ($)', currency: 'A$', taxLabel: 'GST', taxRate: 10 },
  { value: 'inr', label: 'India · INR (₹)', currency: '₹', taxLabel: 'GST', taxRate: 5 },
  { value: 'bdt', label: 'Bangladesh · BDT (৳)', currency: '৳', taxLabel: 'VAT', taxRate: 5 },
  { value: 'pkr', label: 'Pakistan · PKR (Rs)', currency: 'Rs', taxLabel: 'GST', taxRate: 15 },
  { value: 'aed', label: 'UAE · AED (AED)', currency: 'AED ', taxLabel: 'VAT', taxRate: 5 },
  { value: 'sar', label: 'Saudi Arabia · SAR (SAR)', currency: 'SAR ', taxLabel: 'VAT', taxRate: 15 },
  { value: 'myr', label: 'Malaysia · MYR (RM)', currency: 'RM', taxLabel: 'SST', taxRate: 6 },
  { value: 'sgd', label: 'Singapore · SGD (S$)', currency: 'S$', taxLabel: 'GST', taxRate: 9 },
  { value: 'try', label: 'Türkiye · TRY (₺)', currency: '₺', taxLabel: 'VAT', taxRate: 10 }
];

export default function SettingsPage() {
  const { data, commit, notify, sync, message, reload } = useStore();
  const [form, setForm] = useState<RestaurantSettings>(data.settings);
  const [dirty, setDirty] = useState(false);

  const set = (patch: Partial<RestaurantSettings>) => {
    setForm(current => ({ ...current, ...patch }));
    setDirty(true);
  };

  const save = () => {
    if (!form.restaurantName.trim() || !form.branchName.trim()) {
      notify('Restaurant and branch names are required.');
      return;
    }
    commit({ settings: { ...form, taxRate: Math.max(0, Math.min(50, Number(form.taxRate) || 0)) } }, { title: 'Settings saved', detail: `${form.restaurantName} · ${form.branchName} · ${form.taxLabel || 'Tax'} ${form.taxRate}%` });
    setDirty(false);
    notify('Branch settings saved to the database.');
  };

  return (
    <div>
      <PageHeader
        eyebrow="Setup"
        title="Settings"
        subtitle="Branch identity, currency, tax and the public menu URL used in QR codes."
        actions={
          <>
            <Button variant="outline" onClick={() => void reload()}><Database size={13} /> Reload from database</Button>
            <Button onClick={save} disabled={!dirty}><Save size={13} /> Save settings</Button>
          </>
        }
      />

      <div className="grid gap-3 lg:grid-cols-[1fr_320px]">
        <div className="space-y-3">
          <div className={`${panel} p-4`}>
            <div className="mb-3 flex items-center gap-2">
              <Store size={14} className="text-accent" />
              <h3 className="text-[12.5px] font-semibold text-ink">Restaurant profile</h3>
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <Labeled label="Restaurant name"><input value={form.restaurantName} onChange={event => set({ restaurantName: event.target.value })} className={inputCls} /></Labeled>
              <Labeled label="Branch name"><input value={form.branchName} onChange={event => set({ branchName: event.target.value })} className={inputCls} /></Labeled>
              <Labeled label="Branch code"><input value={form.branchCode} onChange={event => set({ branchCode: event.target.value.toUpperCase() })} className={`${inputCls} font-mono`} /></Labeled>
              <Labeled label="Phone"><input value={form.phone} onChange={event => set({ phone: event.target.value })} className={inputCls} /></Labeled>
              <Labeled label="Address" className="sm:col-span-2"><textarea value={form.address} onChange={event => set({ address: event.target.value })} className={textareaCls} /></Labeled>
            </div>
          </div>

          <div className={`${panel} p-4`}>
            <div className="mb-3 flex items-center gap-2">
              <Percent size={14} className="text-accent" />
              <h3 className="text-[12.5px] font-semibold text-ink">Billing & receipts</h3>
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <Labeled label="Region preset" hint="Fills currency, tax name and a typical rate — every value stays editable." className="sm:col-span-2">
                <Select
                  value={regionPresets.find(preset => preset.currency === form.currency && preset.taxLabel === form.taxLabel && preset.taxRate === form.taxRate && preset.value !== 'custom')?.value ?? 'custom'}
                  onChange={value => {
                    const preset = regionPresets.find(entry => entry.value === value);
                    if (preset && preset.value !== 'custom') set({ currency: preset.currency, taxLabel: preset.taxLabel, taxRate: preset.taxRate });
                  }}
                  options={regionPresets.map(preset => ({ value: preset.value, label: preset.label }))}
                />
              </Labeled>
              <Labeled label="Currency symbol"><input value={form.currency} onChange={event => set({ currency: event.target.value })} className={inputCls} placeholder="$" /></Labeled>
              <Labeled label="Tax name" hint="Shown on bills and the guest menu (VAT, GST, Sales tax…).">
                <input value={form.taxLabel} onChange={event => set({ taxLabel: event.target.value })} className={inputCls} placeholder="Tax" />
              </Labeled>
              <Labeled label={`${form.taxLabel || 'Tax'} rate (%)`} hint="Applied to every bill after discounts.">
                <input type="number" min="0" max="50" step="0.5" value={form.taxRate} onChange={event => set({ taxRate: Number(event.target.value) })} className={inputCls} />
              </Labeled>
              <Labeled label="Receipt footer" className="sm:col-span-2">
                <textarea value={form.receiptFooter} onChange={event => set({ receiptFooter: event.target.value })} className={textareaCls} />
              </Labeled>
            </div>
          </div>

          <div className={`${panel} p-4`}>
            <div className="mb-3 flex items-center gap-2">
              <Building2 size={14} className="text-accent" />
              <h3 className="text-[12.5px] font-semibold text-ink">QR menu channel</h3>
            </div>
            <Labeled label="Public menu base URL" hint="Encoded in every table QR code. Point it at your hosted guest menu.">
              <input value={form.publicMenuUrl} onChange={event => set({ publicMenuUrl: event.target.value })} className={inputCls} />
            </Labeled>
          </div>
        </div>

        <div className="space-y-3">
          <div className={`${panel} p-4`}>
            <div className="mb-2 flex items-center gap-2">
              <Server size={14} className="text-accent" />
              <h3 className="text-[12.5px] font-semibold text-ink">Backend status</h3>
            </div>
            <div className="space-y-1.5 text-[11px]">
              <div className="flex items-center justify-between"><span className="text-mute">API engine</span><Badge tone="blue">Express · SQLite</Badge></div>
              <div className="flex items-center justify-between"><span className="text-mute">Database file</span><span className="font-mono text-[10px] text-ink2">data/pos.db</span></div>
              <div className="flex items-center justify-between"><span className="text-mute">Sync state</span><Badge tone={sync === 'error' ? 'red' : sync === 'offline' ? 'amber' : 'green'}>{sync === 'idle' ? 'connected' : sync}</Badge></div>
              <div className="flex items-center justify-between"><span className="text-mute">Auth</span><span className="text-ink2">JWT · bcrypt</span></div>
            </div>
            {message ? <div className="mt-2 rounded-lg border border-amber-400/20 bg-amber-400/[.07] px-2.5 py-2 text-[10.5px] text-amber-900">{message}</div> : null}
            <div className="mt-2 rounded-lg border border-line bg-sunken px-2.5 py-2 text-[10px] leading-5 text-mute2">
              Every change in the console is written back to SQLite. Use <span className="font-mono text-ink2">npm run db:seed</span> to re-seed a fresh database.
            </div>
          </div>

          <div className={`${panel} p-4`}>
            <h3 className="text-[12.5px] font-semibold text-ink">Data footprint</h3>
            <div className="mt-2 grid grid-cols-2 gap-1.5 text-[10.5px]">
              {[
                ['Orders', data.orders.length],
                ['Menu items', data.products.length],
                ['Ingredients', data.inventory.length],
                ['Customers', data.customers.length],
                ['Employees', data.employees.length],
                ['Ledger entries', data.payments.length]
              ].map(([label, value]) => (
                <div key={String(label)} className="rounded-lg border border-line bg-sunken px-2 py-1.5">
                  <div className="text-mute2">{label}</div>
                  <div className="text-[12px] font-medium text-ink">{value}</div>
                </div>
              ))}
            </div>
          </div>

          <div className={`${panel} p-4`}>
            <h3 className="text-[12.5px] font-semibold text-ink">Preview</h3>
            <div className="mt-2 rounded-xl border border-line bg-sunken p-3 text-ink">
              <div className="font-serif text-[15px]">{form.restaurantName}</div>
              <div className="text-[9.5px] uppercase tracking-[.18em] text-accent">{form.branchName}</div>
              <div className="mt-1 text-[9.5px] text-mute">{form.address}</div>
              <div className="text-[9.5px] text-mute">{form.phone}</div>
              <div className="my-1.5 border-t border-dashed border-line2" />
              <div className="flex justify-between text-[10px]"><span>Sample burger</span><span>{form.currency}250</span></div>
              <div className="flex justify-between text-[10px]"><span>{form.taxLabel || 'Tax'} ({form.taxRate}%)</span><span>{form.currency}{((250 * form.taxRate) / 100).toFixed(0)}</span></div>
              <div className="mt-1 flex justify-between border-t border-line2 pt-1 text-[11px] font-semibold"><span>Total</span><span>{form.currency}{(250 + (250 * form.taxRate) / 100).toFixed(0)}</span></div>
              <div className="mt-2 text-center text-[8.5px] text-mute2">{form.receiptFooter}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
