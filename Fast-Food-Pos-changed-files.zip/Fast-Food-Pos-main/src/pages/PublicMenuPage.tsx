import { useEffect, useMemo, useState } from 'react';
import { Bike, Check, ChevronLeft, Loader2, MapPin, Minus, Phone, Plus, ShoppingBag, Store, X } from 'lucide-react';
import { useStore } from '../store';
import MenuBrowser, { dealPercent, FoodImage } from '../components/MenuBrowser';
import { api, type GuestOrderReceipt } from '../lib/api';
import { computeTotals, projectedStock } from '../lib/pos';
import type { Product } from '../types';

interface GuestLine {
  productId: string;
  qty: number;
  note: string;
}

const STEPS = ['Pending', 'Accepted', 'Preparing', 'Ready', 'Completed'] as const;
const stepLabel: Record<string, string> = {
  Pending: 'Received',
  Accepted: 'Accepted',
  Preparing: 'Preparing',
  Ready: 'Ready',
  Completed: 'Served',
  Cancelled: 'Cancelled'
};

const ORDER_KEY = 'guest-orders-v2';
const FINAL = ['Completed', 'Cancelled'];

function readHistory(): GuestOrderReceipt[] {
  try {
    const raw = localStorage.getItem(ORDER_KEY);
    const list = raw ? (JSON.parse(raw) as GuestOrderReceipt[]) : [];
    return Array.isArray(list) ? list.slice(0, 10) : [];
  } catch {
    return [];
  }
}

function writeHistory(list: GuestOrderReceipt[]): GuestOrderReceipt[] {
  try {
    localStorage.setItem(ORDER_KEY, JSON.stringify(list));
  } catch {
    /* storage can be unavailable in private mode */
  }
  return list;
}

export default function PublicMenuPage() {
  const { data, ready, money, reload } = useStore();
  const params = new URLSearchParams(window.location.search);
  const tableNumber = params.get('table');
  const table = tableNumber ? data.tables.find(entry => entry.number.toLowerCase() === tableNumber.toLowerCase()) : undefined;

  const [cart, setCart] = useState<GuestLine[]>([]);
  const [selected, setSelected] = useState<Product | null>(null);
  const [selectedQty, setSelectedQty] = useState(1);
  const [selectedNote, setSelectedNote] = useState('');
  const [cartOpen, setCartOpen] = useState(false);
  const [mode, setMode] = useState<'Pickup' | 'Home Delivery'>('Pickup');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [history, setHistory] = useState<GuestOrderReceipt[]>(readHistory);
  const [showAll, setShowAll] = useState(false);
  const receipt = history[0] ?? null;

  useEffect(() => {
    document.title = `${data.settings.restaurantName} · Menu`;
  }, [data.settings.restaurantName]);

  const lines = useMemo(
    () =>
      cart
        .map(line => ({ line, product: data.products.find(product => product.id === line.productId) }))
        .filter((entry): entry is { line: GuestLine; product: Product } => Boolean(entry.product)),
    [cart, data.products]
  );
  const count = lines.reduce((sum, entry) => sum + entry.line.qty, 0);
  const totals = computeTotals(
    lines.map(entry => ({ price: entry.product.price, qty: entry.line.qty })),
    data.settings.taxRate
  );

  const openProduct = (product: Product) => {
    const existing = cart.find(line => line.productId === product.id);
    setSelected(product);
    setSelectedQty(existing?.qty ?? 1);
    setSelectedNote(existing?.note ?? '');
  };

  const saveSelected = () => {
    if (!selected) return;
    setCart(current => {
      const rest = current.filter(line => line.productId !== selected.id);
      return selectedQty > 0 ? [...rest, { productId: selected.id, qty: selectedQty, note: selectedNote.trim() }] : rest;
    });
    setSelected(null);
  };

  const changeQty = (productId: string, delta: number) =>
    setCart(current =>
      current
        .map(line => (line.productId === productId ? { ...line, qty: Math.min(30, line.qty + delta) } : line))
        .filter(line => line.qty > 0)
    );

  const placeOrder = async () => {
    setError(null);
    if (lines.length === 0) return;
    if (!table && mode === 'Home Delivery' && (!phone.trim() || !address.trim())) {
      setError('Please add your phone number and delivery address.');
      return;
    }
    setBusy(true);
    try {
      const result = await api.placeGuestOrder({
        table: table?.number,
        type: table ? undefined : mode,
        name: name.trim() || undefined,
        phone: phone.trim() || undefined,
        address: mode === 'Home Delivery' ? address.trim() : undefined,
        note: note.trim() || undefined,
        items: lines.map(entry => ({ productId: entry.product.id, qty: entry.line.qty, note: entry.line.note || undefined }))
      });
      setHistory(current => writeHistory([result, ...current].slice(0, 10)));
      setCart([]);
      setCartOpen(false);
      setNote('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not send your order. Please call the counter.');
    } finally {
      setBusy(false);
    }
  };

  // live status of every order this guest placed from this phone
  const activeIds = history.filter(order => !FINAL.includes(order.status)).map(order => order.id).join(',');
  useEffect(() => {
    if (!activeIds) return;
    const refresh = async () => {
      const ids = activeIds.split(',');
      const updates = await Promise.all(ids.map(id => api.guestOrderStatus(id).catch(() => null)));
      const fresh = updates.filter((entry): entry is GuestOrderReceipt => Boolean(entry));
      if (fresh.length === 0) return;
      setHistory(current => writeHistory(current.map(order => fresh.find(entry => entry.id === order.id) ?? order)));
    };
    const timer = window.setInterval(() => void refresh(), 6000);
    return () => window.clearInterval(timer);
  }, [activeIds]);

  const activeProducts = data.products.filter(product => product.active !== false);
  const stepIndex = receipt ? STEPS.indexOf(receipt.status as (typeof STEPS)[number]) : -1;

  return (
    <div className="min-h-screen bg-page pb-28 text-ink">
      <header className="border-b border-line bg-surface">
        <div className="mx-auto max-w-5xl px-4 pb-5 pt-6">
          <div className="flex items-center gap-3">
            <div className="grid h-11 w-11 place-items-center rounded-2xl bg-ink font-serif text-xl font-bold text-white">
              {(data.settings.restaurantName || 'M').slice(0, 1).toUpperCase()}
            </div>
            <div className="min-w-0">
              <div className="text-[9.5px] font-semibold uppercase tracking-[.28em] text-mute2">{data.settings.branchName}</div>
              <h1 className="truncate font-serif text-[24px] leading-tight text-ink">{data.settings.restaurantName}</h1>
            </div>
            {table ? (
              <span className="ml-auto shrink-0 rounded-full bg-ink px-3 py-1.5 text-[11px] font-semibold text-white">Table {table.number}</span>
            ) : null}
          </div>
          <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-[11px] text-mute2">
            {data.settings.address ? (
              <span className="inline-flex items-center gap-1">
                <MapPin size={11} /> {data.settings.address}
              </span>
            ) : null}
            {data.settings.phone ? (
              <span className="inline-flex items-center gap-1">
                <Phone size={11} /> {data.settings.phone}
              </span>
            ) : null}
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-4 pt-4">
        {receipt ? (
          <section className="mb-4 rounded-2xl border border-ink bg-surface p-4 shadow-card">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="text-[10px] font-semibold uppercase tracking-[.2em] text-mute2">Your order</div>
                <div className="font-serif text-[22px] leading-tight">#{receipt.number}</div>
                <div className="text-[11px] text-mute2">
                  {receipt.type} · {money(receipt.total)}
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span
                  className={`rounded-full px-2.5 py-1 text-[10.5px] font-semibold ${
                    receipt.status === 'Cancelled' ? 'bg-rose-50 text-rose-700' : receipt.status === 'Ready' || receipt.status === 'Completed' ? 'bg-emerald-50 text-emerald-700' : 'bg-sunken text-ink2'
                  }`}
                >
                  {stepLabel[receipt.status] ?? receipt.status}
                </span>
                <button
                  onClick={() => setHistory(current => writeHistory(current.slice(1)))}
                  className="rounded-lg p-1.5 text-mute2 hover:bg-sunken"
                  aria-label="Dismiss order status"
                >
                  <X size={15} />
                </button>
              </div>
            </div>
            {receipt.status !== 'Cancelled' ? (
              <div className="mt-3 flex items-center gap-1">
                {STEPS.map((step, index) => (
                  <div key={step} className="flex flex-1 flex-col gap-1">
                    <div className={`h-1.5 rounded-full ${index <= stepIndex ? 'bg-ink' : 'bg-line'}`} />
                    <span className={`text-[9px] ${index <= stepIndex ? 'font-semibold text-ink' : 'text-faint'}`}>{stepLabel[step]}</span>
                  </div>
                ))}
              </div>
            ) : null}
            {history.length > 1 ? (
              <div className="mt-3 border-t border-line pt-2.5">
                <button onClick={() => setShowAll(value => !value)} className="text-[11px] font-semibold text-ink2 hover:text-ink">
                  {showAll ? 'Hide' : 'My orders'} ({history.length})
                </button>
                {showAll ? (
                  <div className="mt-2 space-y-1.5">
                    {history.map(order => (
                      <div key={order.id} className="flex items-center justify-between rounded-lg bg-sunken px-2.5 py-1.5 text-[11.5px]">
                        <span className="font-semibold">#{order.number}</span>
                        <span className="text-mute2">{order.type} · {money(order.total)}</span>
                        <span className="font-medium">{stepLabel[order.status] ?? order.status}</span>
                      </div>
                    ))}
                  </div>
                ) : null}
              </div>
            ) : null}
          </section>
        ) : null}

        {!ready ? (
          <div className="grid place-items-center py-24 text-[12px] text-mute2">
            <Loader2 className="mb-2 animate-spin" size={20} /> Loading menu…
          </div>
        ) : activeProducts.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-line2 bg-surface px-6 py-16 text-center">
            <Store className="mx-auto text-faint" size={26} />
            <div className="mt-2 text-[13px] font-semibold">The menu is not available right now</div>
            <div className="mt-1 text-[11.5px] text-mute2">Please ask the counter team, or try again in a moment.</div>
            <button onClick={() => void reload()} className="mt-4 rounded-xl bg-ink px-4 py-2 text-[12px] font-semibold text-white">
              Try again
            </button>
          </div>
        ) : (
          <MenuBrowser
            products={data.products}
            categories={data.categories}
            money={money}
            onSelect={openProduct}
            qtyOf={productId => cart.find(line => line.productId === productId)?.qty ?? 0}
            stockOf={product => {
              const left = projectedStock(data.products, data.inventory, product.id);
              return left !== null && left <= 0 ? 0 : null;
            }}
            columns="grid-cols-2 md:grid-cols-3 lg:grid-cols-4"
          />
        )}

        <p className="mt-6 text-center text-[10.5px] text-faint">
          {data.settings.taxLabel || 'Tax'} {data.settings.taxRate}% is added at checkout · {data.settings.receiptFooter}
        </p>
      </main>

      {count > 0 && !cartOpen ? (
        <div className="fixed inset-x-0 bottom-0 z-40 p-3">
          <button
            onClick={() => setCartOpen(true)}
            className="rise mx-auto flex w-full max-w-md items-center justify-between rounded-2xl bg-ink px-4 py-3.5 text-white shadow-pop"
          >
            <span className="flex items-center gap-2 text-[13px] font-semibold">
              <span className="grid h-6 min-w-6 place-items-center rounded-full bg-white px-1.5 text-[11px] font-bold text-ink">{count}</span>
              View your order
            </span>
            <span className="font-serif text-[16px]">{money(totals.total)}</span>
          </button>
        </div>
      ) : null}

      {selected ? (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/40 backdrop-blur-sm sm:items-center sm:p-4" onClick={() => setSelected(null)}>
          <div className="rise w-full max-w-md overflow-hidden rounded-t-3xl bg-surface shadow-pop sm:rounded-3xl" onClick={event => event.stopPropagation()}>
            <div className="relative aspect-[16/10] bg-sunken">
              <FoodImage src={selected.image} name={selected.name} className="h-full w-full object-cover" />
              <button onClick={() => setSelected(null)} className="absolute right-3 top-3 grid h-8 w-8 place-items-center rounded-full bg-surface text-ink shadow-md" aria-label="Close">
                <X size={16} />
              </button>
            </div>
            <div className="p-5">
              <div className="text-[10px] font-semibold uppercase tracking-[.2em] text-mute2">{selected.category}</div>
              <div className="mt-1 flex items-start justify-between gap-3">
                <h2 className="font-serif text-[22px] leading-tight">{selected.name}</h2>
                <div className="text-right">
                  <div className="font-serif text-[20px]">{money(selected.price)}</div>
                  {dealPercent(selected) > 0 && selected.comparePrice ? (
                    <div className="text-[11px] text-faint">
                      <span className="line-through">{money(selected.comparePrice)}</span> <span className="font-semibold text-rose-600">{dealPercent(selected)}% off</span>
                    </div>
                  ) : null}
                </div>
              </div>
              {selected.recipe.length > 0 ? (
                <p className="mt-2 text-[11.5px] leading-5 text-mute2">Made with {selected.recipe.map(usage => usage.name.toLowerCase()).join(', ')}.</p>
              ) : null}
              <input
                value={selectedNote}
                onChange={event => setSelectedNote(event.target.value)}
                placeholder="Special request (no onions, extra sauce…)"
                className="mt-3 w-full rounded-xl border border-line bg-surface px-3 py-2.5 text-[12.5px] outline-none placeholder:text-faint focus:border-ink"
              />
              <div className="mt-4 flex items-center gap-3">
                <div className="flex items-center gap-1 rounded-xl border border-line p-1">
                  <button onClick={() => setSelectedQty(value => Math.max(0, value - 1))} className="qty-btn" aria-label="Decrease">
                    <Minus size={13} />
                  </button>
                  <span className="w-7 text-center text-[13px] font-semibold">{selectedQty}</span>
                  <button onClick={() => setSelectedQty(value => Math.min(30, value + 1))} className="qty-btn" aria-label="Increase">
                    <Plus size={13} />
                  </button>
                </div>
                <button onClick={saveSelected} className="flex-1 rounded-xl bg-ink px-4 py-3 text-[13px] font-semibold text-white hover:bg-ink2">
                  {selectedQty === 0 ? 'Remove from order' : `Add to order · ${money(selected.price * selectedQty)}`}
                </button>
              </div>
            </div>
          </div>
        </div>
      ) : null}

      {cartOpen ? (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/40 backdrop-blur-sm sm:items-center sm:p-4" onClick={() => setCartOpen(false)}>
          <div className="rise flex max-h-[92vh] w-full max-w-md flex-col overflow-hidden rounded-t-3xl bg-surface shadow-pop sm:rounded-3xl" onClick={event => event.stopPropagation()}>
            <div className="flex items-center justify-between border-b border-line px-5 py-4">
              <button onClick={() => setCartOpen(false)} className="inline-flex items-center gap-1 text-[12px] text-mute hover:text-ink">
                <ChevronLeft size={15} /> Menu
              </button>
              <h2 className="font-serif text-[19px]">Your order</h2>
              <span className="w-12" />
            </div>

            <div className="custom-scrollbar flex-1 overflow-y-auto px-5 py-4">
              <div className="space-y-2">
                {lines.map(({ line, product }) => (
                  <div key={product.id} className="flex items-center gap-3 rounded-xl border border-line p-2">
                    <FoodImage src={product.image} name={product.name} className="h-12 w-12 shrink-0 overflow-hidden rounded-lg bg-sunken object-cover text-[12px]" />
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-[12.5px] font-semibold">{product.name}</div>
                      <div className="text-[10.5px] text-mute2">{money(product.price)}{line.note ? ` · “${line.note}”` : ''}</div>
                    </div>
                    <div className="flex items-center gap-1">
                      <button onClick={() => changeQty(product.id, -1)} className="qty-btn" aria-label="Decrease">
                        <Minus size={12} />
                      </button>
                      <span className="w-5 text-center text-[12px] font-semibold">{line.qty}</span>
                      <button onClick={() => changeQty(product.id, 1)} className="qty-btn" aria-label="Increase">
                        <Plus size={12} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {!table ? (
                <div className="mt-4 grid grid-cols-2 gap-1.5">
                  {([
                    { value: 'Pickup', label: 'Pickup', icon: Store },
                    { value: 'Home Delivery', label: 'Delivery', icon: Bike }
                  ] as const).map(option => (
                    <button
                      key={option.value}
                      onClick={() => setMode(option.value)}
                      className={`flex items-center justify-center gap-1.5 rounded-xl border px-3 py-2.5 text-[12px] font-medium transition ${
                        mode === option.value ? 'border-ink bg-ink text-white' : 'border-line text-mute hover:border-line2'
                      }`}
                    >
                      <option.icon size={13} /> {option.label}
                    </button>
                  ))}
                </div>
              ) : (
                <div className="mt-4 rounded-xl bg-sunken px-3 py-2.5 text-[11.5px] text-ink2">Served to your table — Table {table.number}.</div>
              )}

              <div className="mt-3 space-y-2">
                <input value={name} onChange={event => setName(event.target.value)} placeholder="Your name (optional)" className="w-full rounded-xl border border-line px-3 py-2.5 text-[12.5px] outline-none placeholder:text-faint focus:border-ink" />
                {!table ? (
                  <input value={phone} onChange={event => setPhone(event.target.value)} inputMode="tel" placeholder={mode === 'Home Delivery' ? 'Phone number (required)' : 'Phone number (optional)'} className="w-full rounded-xl border border-line px-3 py-2.5 text-[12.5px] outline-none placeholder:text-faint focus:border-ink" />
                ) : null}
                {!table && mode === 'Home Delivery' ? (
                  <input value={address} onChange={event => setAddress(event.target.value)} placeholder="Delivery address (required)" className="w-full rounded-xl border border-line px-3 py-2.5 text-[12.5px] outline-none placeholder:text-faint focus:border-ink" />
                ) : null}
                <input value={note} onChange={event => setNote(event.target.value)} placeholder="Note for the kitchen (optional)" className="w-full rounded-xl border border-line px-3 py-2.5 text-[12.5px] outline-none placeholder:text-faint focus:border-ink" />
              </div>
            </div>

            <div className="border-t border-line bg-surface px-5 pb-5 pt-3">
              <div className="space-y-1 text-[12px]">
                <div className="flex justify-between text-mute">
                  <span>Subtotal</span>
                  <span className="text-ink">{money(totals.subtotal)}</span>
                </div>
                <div className="flex justify-between text-mute">
                  <span>
                    {data.settings.taxLabel || 'Tax'} ({data.settings.taxRate}%)
                  </span>
                  <span className="text-ink">{money(totals.tax)}</span>
                </div>
                <div className="flex justify-between pt-1 text-[14px] font-semibold">
                  <span>Total</span>
                  <span className="font-serif text-[18px]">{money(totals.total)}</span>
                </div>
              </div>
              {error ? <div role="alert" className="mt-2 rounded-lg border border-rose-300 bg-rose-50 px-3 py-2 text-[11.5px] text-rose-700">{error}</div> : null}
              <button
                onClick={() => void placeOrder()}
                disabled={busy || lines.length === 0}
                className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl bg-ink px-4 py-3.5 text-[13.5px] font-semibold text-white transition hover:bg-ink2 disabled:opacity-50"
              >
                {busy ? <Loader2 size={15} className="animate-spin" /> : <Check size={15} />}
                {busy ? 'Sending…' : 'Place order'}
              </button>
              <div className="mt-2 flex items-center justify-center gap-1 text-[10px] text-faint">
                <ShoppingBag size={11} /> Pay at the counter when you receive your order
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
