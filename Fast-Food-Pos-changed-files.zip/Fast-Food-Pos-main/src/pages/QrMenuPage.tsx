import { useEffect, useMemo, useState } from 'react';
import { Download, ExternalLink, Link2, Printer, QrCode, RefreshCw, Smartphone } from 'lucide-react';
import { useStore } from '../store';
import { Badge, Button, Labeled, PageHeader, panel, Select, inputCls } from '../components/ui';
import MenuBrowser from '../components/MenuBrowser';
import { qrUrl } from '../lib/api';
import { isToday } from '../lib/pos';

export default function QrMenuPage() {
  const { data, money, notify } = useStore();
  const [tableId, setTableId] = useState(data.tables[0]?.id ?? '');
  const defaultMenuUrl = () => {
    const stored = data.settings.publicMenuUrl;
    if (!stored || stored.includes('musafir-pos.local')) return `${window.location.origin}/menu`;
    return stored;
  };
  const [baseUrl, setBaseUrl] = useState(defaultMenuUrl);
  const [bust, setBust] = useState(0);

  const table = data.tables.find(entry => entry.id === tableId) ?? data.tables[0];
  const resolvedBase = baseUrl || `${window.location.origin}/menu`;
  const src = useMemo(
    () => qrUrl(table?.number ?? 'T-01', resolvedBase, data.settings.branchCode) + `&v=${bust}`,
    [table?.number, resolvedBase, data.settings.branchCode, bust]
  );

  useEffect(() => {
    if (!tableId && data.tables[0]) setTableId(data.tables[0].id);
  }, [tableId, data.tables]);

  const publicLink = `${resolvedBase.replace(/\/$/, '')}?branch=${encodeURIComponent(data.settings.branchCode)}&table=${encodeURIComponent(table?.number ?? '')}`;
  const liveProducts = data.products.filter(product => product.active !== false);
  const categories = Array.from(new Set(liveProducts.map(product => product.category)));
  const guestOrders = data.orders.filter(order => order.id.startsWith('qr-'));
  const guestToday = guestOrders.filter(order => isToday(order.createdAt) && order.status !== 'Cancelled');

  const printSheet = () => {
    const win = window.open('', '_blank', 'width=720,height=900');
    if (!win) return;
    win.document.write(`<!doctype html><html><head><title>QR table cards</title><style>
      body{font-family:ui-sans-serif,system-ui,sans-serif;padding:24px;color:#0e0e10}
      h1{font-size:18px;margin:0 0 4px}p{color:#666;font-size:12px;margin:0 0 18px}
      .grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}
      .card{border:1.5px solid #0e0e10;border-radius:16px;padding:16px;text-align:center}
      .table{font-size:24px;font-weight:800}.brand{font-size:10px;letter-spacing:2px;color:#555;text-transform:uppercase}
      img{width:180px;height:180px;margin:8px auto}.hint{font-size:10px;color:#777}
      @media print{.card{break-inside:avoid}}</style></head><body>
      <h1>${data.settings.restaurantName} — QR menu cards</h1>
      <p>${data.settings.branchName} · scan to view the menu and order from your phone</p>
      <div class="grid">${data.tables
        .map(
          entry => `<div class="card"><div class="brand">${data.settings.restaurantName}</div><div class="table">${entry.number}</div>
          <img src="${qrUrl(entry.number, resolvedBase, data.settings.branchCode)}" alt="${entry.number} QR" />
          <div class="hint">Scan to view the menu &amp; order</div></div>`
        )
        .join('')}</div></body></html>`);
    win.document.close();
    win.setTimeout(() => win.print(), 900);
  };

  return (
    <div>
      <PageHeader
        eyebrow="Digital channel"
        title="QR menu"
        subtitle="Every table gets a code that opens the live menu. Guests order from their phone and the ticket lands in Orders and the kitchen."
        actions={
          <>
            <Button variant="outline" onClick={() => setBust(value => value + 1)}>
              <RefreshCw size={13} /> Refresh code
            </Button>
            <Button onClick={printSheet}>
              <Printer size={13} /> Print table cards
            </Button>
          </>
        }
      />

      <div className="mb-3 grid gap-3 sm:grid-cols-3">
        {[
          ['Live items', liveProducts.length],
          ['Guest orders today', guestToday.length],
          ['Waiting for the kitchen', guestOrders.filter(order => order.status === 'Pending').length]
        ].map(([label, value]) => (
          <div key={String(label)} className={`${panel} px-4 py-3`}>
            <div className="text-[10px] font-semibold uppercase tracking-[.16em] text-mute2">{label}</div>
            <div className="mt-1 font-serif text-[24px] leading-none">{value}</div>
          </div>
        ))}
      </div>

      <div className="grid gap-3 lg:grid-cols-[340px_1fr]">
        <div className={`${panel} p-4`}>
          <div className="flex items-center justify-between">
            <h3 className="text-[12.5px] font-semibold">Table QR code</h3>
            <Badge tone="green">
              <QrCode size={9} /> live
            </Badge>
          </div>
          <div className="mt-3 rounded-2xl border border-line bg-surface p-4">
            <img src={src} alt={`QR code for ${table?.number ?? 'table'}`} className="mx-auto h-[220px] w-[220px] object-contain" />
            <div className="mt-2 text-center text-[10px] font-semibold uppercase tracking-[.18em] text-mute2">{data.settings.restaurantName}</div>
            <div className="text-center font-serif text-[22px]">{table?.number ?? 'T-01'}</div>
          </div>

          <div className="mt-3 space-y-2.5">
            <Labeled label="Table">
              <Select value={tableId} onChange={setTableId} options={data.tables.map(entry => ({ value: entry.id, label: `${entry.number} · ${entry.zone}` }))} />
            </Labeled>
            <Labeled label="Public menu base URL" hint="Encoded in the QR — point it at your hosted menu (it must reach this API).">
              <input value={baseUrl} onChange={event => setBaseUrl(event.target.value)} className={inputCls} />
            </Labeled>
            <div className="flex gap-1.5">
              <a
                href={src}
                download={`qr-${table?.number ?? 'table'}.png`}
                className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-ink px-3 py-2 text-[12px] font-semibold text-white hover:bg-ink2"
              >
                <Download size={13} /> Download PNG
              </a>
              <a href={publicLink} target="_blank" rel="noreferrer" className="inline-flex items-center justify-center gap-1.5 rounded-xl border border-line2 px-3 py-2 text-[12px] text-ink hover:border-ink">
                <ExternalLink size={13} /> Open
              </a>
            </div>
            <button
              onClick={() => {
                void navigator.clipboard.writeText(publicLink).then(() => notify('Menu link copied to clipboard.')).catch(() => notify(publicLink));
              }}
              className="flex w-full items-center gap-1.5 rounded-lg border border-line bg-sunken px-2.5 py-2 text-left text-[10px] text-mute2 hover:text-ink"
            >
              <Link2 size={11} className="shrink-0" /> <span className="truncate">{publicLink}</span>
            </button>
          </div>
        </div>

        <div className={`${panel} p-4`}>
          <div className="flex flex-wrap items-start justify-between gap-2">
            <div>
              <h3 className="text-[12.5px] font-semibold">Guest menu preview</h3>
              <p className="mt-0.5 text-[10.5px] text-mute2">
                {liveProducts.length} live items across {categories.length} categories — the same menu, cards and categories as the POS counter.
              </p>
            </div>
            <Badge tone="slate">
              <Smartphone size={9} /> Synced with menu management
            </Badge>
          </div>

          <div className="mt-3 rounded-2xl border border-line bg-page p-3 sm:p-4">
            <div className="mb-3 flex items-center justify-between border-b border-line pb-3">
              <div>
                <div className="font-serif text-[19px] leading-tight">{data.settings.restaurantName}</div>
                <div className="text-[10px] font-semibold uppercase tracking-[.18em] text-mute2">
                  {data.settings.branchName} · Table {table?.number ?? 'T-01'}
                </div>
              </div>
              <div className="text-right text-[10px] text-mute2">
                {data.settings.phone}
                <br />
                {data.settings.taxLabel || 'Tax'} {data.settings.taxRate}%
              </div>
            </div>
            <MenuBrowser products={data.products} categories={data.categories} money={money} columns="grid-cols-2 md:grid-cols-3" />
          </div>
        </div>
      </div>

      <div className={`${panel} mt-3 p-4`}>
        <h3 className="text-[12.5px] font-semibold">All table codes</h3>
        <div className="mt-2.5 grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
          {data.tables.map(entry => (
            <button
              key={entry.id}
              onClick={() => setTableId(entry.id)}
              className={`rounded-xl border p-2 text-left transition ${entry.id === tableId ? 'border-ink bg-sunken' : 'border-line hover:border-line2'}`}
            >
              <div className="rounded-lg border border-line bg-surface p-1.5">
                <img src={qrUrl(entry.number, resolvedBase, data.settings.branchCode)} alt={`${entry.number} QR`} className="mx-auto h-24 w-24 object-contain" />
              </div>
              <div className="mt-1.5 flex items-center justify-between">
                <span className="text-[11.5px] font-semibold">{entry.number}</span>
                <Badge tone={entry.status === 'Occupied' ? 'red' : 'slate'}>{entry.status}</Badge>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
