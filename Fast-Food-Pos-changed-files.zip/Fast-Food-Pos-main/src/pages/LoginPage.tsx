import { useState } from 'react';
import { ChefHat, Eye, EyeOff, Loader2, Lock, ShieldCheck } from 'lucide-react';
import { useStore } from '../store';
import { Button, inputCls, Labeled } from '../components/ui';

const demoAccounts = [
  { email: 'admin@musafir.local', role: 'Owner' },
  { email: 'manager@musafir.local', role: 'Manager' },
  { email: 'cashier@musafir.local', role: 'Cashier' },
  { email: 'kitchen@musafir.local', role: 'Kitchen' }
];

export default function LoginPage() {
  const { data, login, authBusy, enterOffline, message } = useStore();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [show, setShow] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const brand = data.settings.restaurantName || 'Restaurant POS';

  const submit = async () => {
    setError(null);
    if (!email.trim() || !password) {
      setError('Enter your work email and password.');
      return;
    }
    try {
      await login(email.trim(), password);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Sign in failed');
    }
  };

  return (
    <div className="grid min-h-screen place-items-center bg-page px-4 py-8">
      <div className="rise grid w-full max-w-4xl overflow-hidden rounded-3xl border border-line bg-surface shadow-pop md:grid-cols-[1.05fr_1fr]">
        <div className="hidden flex-col justify-between gap-8 bg-ink p-9 text-white md:flex">
          <div>
            <div className="flex items-center gap-3">
              <div className="grid h-11 w-11 place-items-center rounded-xl bg-white text-ink">
                <ChefHat size={22} />
              </div>
              <div>
                <div className="font-serif text-xl font-bold tracking-wide">{brand}</div>
                <div className="text-[9px] uppercase tracking-[.3em] text-white/55">{data.settings.branchName}</div>
              </div>
            </div>
            <h1 className="mt-10 font-serif text-[32px] leading-tight">
              Every order,
              <br />
              from table to ledger.
            </h1>
            <p className="mt-3 max-w-sm text-[12.5px] leading-6 text-white/65">
              Billing, kitchen display, guest QR ordering, recipe-linked stock, payroll and profit reporting in one branch console.
            </p>
          </div>
          <div className="space-y-3">
            {['Guests order from their phone, tickets reach the kitchen live', 'Recipe-linked stock with automatic low-stock alerts', 'Daily cash, dues, supplier and payroll ledger'].map(line => (
              <div key={line} className="flex items-start gap-2.5 text-[11.5px] text-white/70">
                <ShieldCheck size={14} className="mt-0.5 shrink-0 text-white" />
                {line}
              </div>
            ))}
          </div>
        </div>

        <div className="p-6 sm:p-9">
          <div className="mb-6 md:hidden">
            <div className="flex items-center gap-2.5">
              <div className="grid h-9 w-9 place-items-center rounded-lg bg-ink text-white">
                <ChefHat size={18} />
              </div>
              <div className="font-serif text-lg font-bold">{brand}</div>
            </div>
          </div>
          <div className="text-[10px] font-semibold uppercase tracking-[.2em] text-mute2">Branch sign in</div>
          <h2 className="mt-1.5 font-serif text-[26px]">Welcome back</h2>
          <p className="mt-1 text-[12px] text-mute2">Use your staff account to open the console.</p>

          <form
            className="mt-6 space-y-3.5"
            onSubmit={event => {
              event.preventDefault();
              void submit();
            }}
          >
            <Labeled label="Work email">
              <input type="email" autoComplete="username" value={email} onChange={event => setEmail(event.target.value)} className={inputCls} placeholder="you@company.com" />
            </Labeled>
            <Labeled label="Password">
              <div className="relative">
                <input
                  type={show ? 'text' : 'password'}
                  autoComplete="current-password"
                  value={password}
                  onChange={event => setPassword(event.target.value)}
                  className={`${inputCls} pr-10`}
                  placeholder="••••••••"
                />
                <button
                  type="button"
                  onClick={() => setShow(value => !value)}
                  aria-label={show ? 'Hide password' : 'Show password'}
                  className="absolute right-2 top-1/2 -translate-y-1/2 rounded-md p-1.5 text-mute2 hover:text-ink"
                >
                  {show ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
            </Labeled>

            {error ? (
              <div role="alert" className="rounded-lg border border-rose-300 bg-rose-50 px-3 py-2 text-[11.5px] text-rose-700">
                {error}
              </div>
            ) : null}
            {message ? <div className="rounded-lg border border-amber-300 bg-amber-50 px-3 py-2 text-[11.5px] text-amber-900">{message}</div> : null}

            <Button type="submit" disabled={authBusy} className="w-full py-2.5">
              {authBusy ? <Loader2 size={15} className="animate-spin" /> : <Lock size={14} />}
              {authBusy ? 'Signing in…' : 'Sign in to console'}
            </Button>
          </form>

          <details className="group mt-5 rounded-xl border border-line bg-sunken px-3 py-2.5">
            <summary className="cursor-pointer list-none text-[11px] font-medium text-mute hover:text-ink">Development accounts</summary>
            <div className="mt-2 grid grid-cols-2 gap-1.5">
              {demoAccounts.map(account => (
                <button
                  key={account.email}
                  type="button"
                  onClick={() => {
                    setEmail(account.email);
                    setPassword('Musafir@2026!');
                    setError(null);
                  }}
                  className="rounded-lg border border-line bg-surface px-2.5 py-1.5 text-left transition hover:border-ink"
                >
                  <div className="text-[11px] font-semibold">{account.role}</div>
                  <div className="truncate font-mono text-[9.5px] text-mute2">{account.email}</div>
                </button>
              ))}
            </div>
            <div className="mt-2 text-[10px] text-mute2">Seeded by <span className="font-mono">npm run db:seed</span>. Change these passwords before going live.</div>
          </details>

          <button type="button" onClick={enterOffline} className="mt-4 w-full text-center text-[10.5px] text-mute2 underline decoration-dotted underline-offset-4 hover:text-ink">
            Continue without the server (local mode)
          </button>
        </div>
      </div>
    </div>
  );
}
