import { useMemo, useState, type ReactNode } from 'react';
import { Search } from 'lucide-react';
import { groupCategories } from '../lib/pos';
import type { Product } from '../types';
import { cx } from './ui';

/* ------------------------------------------------------------------
   One menu experience shared by the POS counter, the guest QR menu and
   the QR preview — same search, same nested categories, same cards.
------------------------------------------------------------------- */


/** Image with a graceful fallback (initial letter) so a missing or blocked photo never leaves an empty box. */
export function FoodImage({ src, name, className }: { src?: string; name: string; className?: string }) {
  const [failed, setFailed] = useState(false);
  if (!src || failed) {
    return (
      <div className={cx('grid place-items-center bg-sunken font-serif text-mute2', className)} aria-label={name}>
        <span className="text-[1.6em] leading-none opacity-70">{name.slice(0, 1).toUpperCase()}</span>
      </div>
    );
  }
  return <img src={src} alt={name} loading="lazy" className={className} onError={() => setFailed(true)} />;
}

export const dealPercent = (product: Pick<Product, 'price' | 'comparePrice'>) =>
  product.comparePrice && product.comparePrice > product.price ? Math.round(((product.comparePrice - product.price) / product.comparePrice) * 100) : 0;

export function CategoryTabs({
  categories,
  value,
  onChange
}: {
  categories: string[];
  value: string;
  onChange: (category: string) => void;
}) {
  const families = useMemo(() => groupCategories(categories), [categories]);
  const activeFamily = families.find(family => family.categories.includes(value))?.id ?? null;
  const [openFamily, setOpenFamily] = useState<string | null>(null);
  const shownFamily = openFamily ?? activeFamily;
  const subCategories = families.find(family => family.id === shownFamily)?.categories ?? [];

  const pill = (active: boolean) =>
    cx(
      'whitespace-nowrap rounded-full border px-3.5 py-1.5 text-[11.5px] font-medium transition',
      active ? 'border-ink bg-ink text-white' : 'border-line bg-surface text-mute hover:border-line2 hover:text-ink'
    );

  return (
    <div>
      <div className="no-scrollbar flex gap-1.5 overflow-x-auto pb-1">
        <button
          type="button"
          onClick={() => {
            setOpenFamily(null);
            onChange('All');
          }}
          className={pill(value === 'All')}
        >
          All
        </button>
        {families.map(family => {
          const active = shownFamily === family.id;
          return (
            <button
              key={family.id}
              type="button"
              onClick={() => {
                // a family with a single category jumps straight to it; otherwise it opens its sub-row
                if (family.categories.length === 1) {
                  setOpenFamily(null);
                  onChange(family.categories[0]);
                } else {
                  setOpenFamily(family.id);
                  if (!family.categories.includes(value)) onChange('All');
                }
              }}
              className={pill(active)}
            >
              {family.label}
              <span className={cx('ml-1.5 text-[10px]', active ? 'text-white/60' : 'text-faint')}>{family.categories.length}</span>
            </button>
          );
        })}
      </div>
      {subCategories.length > 1 ? (
        <div className="no-scrollbar mt-1.5 flex gap-1.5 overflow-x-auto rounded-xl bg-sunken p-1.5">
          <button
            type="button"
            onClick={() => onChange('All')}
            className={cx('whitespace-nowrap rounded-lg px-2.5 py-1 text-[11px] font-medium transition', value === 'All' ? 'bg-surface text-ink shadow-sm' : 'text-mute hover:text-ink')}
          >
            Everything
          </button>
          {subCategories.map(name => (
            <button
              key={name}
              type="button"
              onClick={() => onChange(name)}
              className={cx('whitespace-nowrap rounded-lg px-2.5 py-1 text-[11px] font-medium transition', value === name ? 'bg-surface text-ink shadow-sm' : 'text-mute hover:text-ink')}
            >
              {name}
            </button>
          ))}
        </div>
      ) : null}
    </div>
  );
}

export function ProductCard({
  product,
  price,
  comparePriceText,
  qty = 0,
  stockLeft = null,
  disabled,
  onSelect
}: {
  product: Product;
  price: string;
  comparePriceText?: string;
  qty?: number;
  stockLeft?: number | null;
  disabled?: boolean;
  onSelect?: (product: Product) => void;
}) {
  const soldOut = stockLeft !== null && stockLeft <= 0;
  const deal = dealPercent(product);
  const interactive = Boolean(onSelect) && !disabled && !soldOut;
  return (
    <button
      type="button"
      onClick={() => interactive && onSelect?.(product)}
      disabled={!interactive}
      className={cx(
        'group relative flex flex-col overflow-hidden rounded-2xl border bg-surface text-left shadow-card transition',
        qty > 0 ? 'border-ink' : 'border-line',
        interactive ? 'hover:-translate-y-0.5 hover:border-ink hover:shadow-soft' : 'cursor-default',
        soldOut ? 'opacity-55' : ''
      )}
    >
      <div className="relative aspect-[4/3] overflow-hidden bg-sunken">
        <FoodImage
          src={product.image}
          name={product.name}
          className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
        />
        {deal > 0 ? (
          <span className="absolute left-2 top-2 rounded-full bg-rose-600 px-2 py-0.5 text-[9px] font-bold uppercase tracking-wide text-white">{deal}% off</span>
        ) : product.popularity >= 90 ? (
          <span className="absolute left-2 top-2 rounded-full bg-ink px-2 py-0.5 text-[9px] font-bold uppercase tracking-wide text-white">Popular</span>
        ) : null}
        {stockLeft !== null ? (
          <span
            className={cx(
              'absolute right-2 top-2 rounded-full px-2 py-0.5 text-[9px] font-semibold',
              soldOut ? 'bg-rose-600 text-white' : stockLeft <= 5 ? 'bg-amber-400 text-ink' : 'bg-surface/90 text-ink2'
            )}
          >
            {soldOut ? 'Sold out' : `${stockLeft} left`}
          </span>
        ) : null}
        {qty > 0 ? (
          <span className="absolute bottom-2 right-2 grid h-6 min-w-6 place-items-center rounded-full bg-ink px-1.5 text-[11px] font-bold text-white shadow-md">{qty}</span>
        ) : null}
      </div>
      <div className="flex flex-1 flex-col p-3">
        <div className="line-clamp-2 min-h-[32px] text-[12.5px] font-semibold leading-4 text-ink">{product.name}</div>
        <div className="mt-auto flex items-end justify-between gap-1 pt-2">
          <span className="flex items-baseline gap-1.5">
            <span className="font-serif text-[15px] leading-none text-ink">{price}</span>
            {deal > 0 && comparePriceText ? <span className="text-[10.5px] text-faint line-through">{comparePriceText}</span> : null}
          </span>
          <span className="truncate text-[9.5px] uppercase tracking-wide text-faint">{product.category}</span>
        </div>
      </div>
    </button>
  );
}

export default function MenuBrowser({
  products,
  categories,
  money,
  onSelect,
  qtyOf,
  stockOf,
  columns = 'grid-cols-2 sm:grid-cols-3 lg:grid-cols-4',
  toolbar,
  emptyText = 'No menu items match this filter.'
}: {
  products: Product[];
  categories: string[];
  money: (amount: number) => string;
  onSelect?: (product: Product) => void;
  qtyOf?: (productId: string) => number;
  stockOf?: (product: Product) => number | null;
  columns?: string;
  toolbar?: ReactNode;
  emptyText?: string;
}) {
  const [category, setCategory] = useState('All');
  const [search, setSearch] = useState('');

  const live = useMemo(() => products.filter(product => product.active !== false), [products]);
  const usedCategories = useMemo(() => categories.filter(name => live.some(product => product.category === name)), [categories, live]);
  const filtered = useMemo(() => {
    const term = search.trim().toLowerCase();
    return live
      .filter(product => category === 'All' || product.category === category)
      .filter(product => !term || product.name.toLowerCase().includes(term) || product.category.toLowerCase().includes(term))
      .sort((a, b) => (b.popularity || 0) - (a.popularity || 0));
  }, [live, category, search]);

  return (
    <div>
      <div className="flex flex-col gap-2.5 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-mute2" />
          <input
            value={search}
            onChange={event => setSearch(event.target.value)}
            placeholder="Search the menu…"
            className="w-full rounded-xl border border-line bg-surface py-2.5 pl-9 pr-3 text-[12.5px] text-ink outline-none transition placeholder:text-faint focus:border-ink focus:ring-2 focus:ring-black/5"
          />
        </div>
        {toolbar ?? <div className="text-[10.5px] text-mute2">{filtered.length} items available</div>}
      </div>

      <div className="mt-3">
        <CategoryTabs categories={usedCategories} value={category} onChange={setCategory} />
      </div>

      <div className={cx('mt-3.5 grid gap-3', columns)}>
        {filtered.map(product => (
          <ProductCard
            key={product.id}
            product={product}
            price={money(product.price)}
            comparePriceText={product.comparePrice ? money(product.comparePrice) : undefined}
            qty={qtyOf?.(product.id) ?? 0}
            stockLeft={stockOf ? stockOf(product) : null}
            onSelect={onSelect}
          />
        ))}
        {filtered.length === 0 ? (
          <div className="col-span-full rounded-2xl border border-dashed border-line2 px-4 py-12 text-center text-[12px] text-mute2">{emptyText}</div>
        ) : null}
      </div>
    </div>
  );
}
