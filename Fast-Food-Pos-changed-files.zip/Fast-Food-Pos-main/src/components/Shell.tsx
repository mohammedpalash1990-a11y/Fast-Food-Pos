import { useEffect, useMemo, useState, type ReactNode } from 'react';
import {
  Activity,
  BarChart3,
  Bell,
  Bike,
  BookOpen,
  Boxes,
  BriefcaseBusiness,
  CalendarDays,
  ChefHat,
  ChevronDown,
  CircleDollarSign,
  ClipboardList,
  CloudOff,
  CreditCard,
  Grid2X2,
  LayoutDashboard,
  Loader2,
  LogOut,
  Menu,
  Package,
  QrCode,
  Search,
  Settings,
  ShieldCheck,
  ShoppingBag,
  ShoppingCart,
  Sparkles,
  Table2,
  Users,
  UtensilsCrossed,
  Wallet,
  X
} from 'lucide-react';
import { useStore } from '../store';
import { rolePermissions, isToday } from '../lib/pos';

export interface NavItem {
  id: string;
  label: string;
  icon: typeof LayoutDashboard;
  hint?: string;
}

export interface NavGroup {
  id: string;
  title: string;
  icon: typeof LayoutDashboard;
  items: NavItem[];
}

/**
 * Navigation is nested: a handful of groups, each holding the screens that belong together.
 * A group with a single screen renders as a plain link.
 */
export const navTree: NavGroup[] = [
  {
    id: 'overview',
    title: 'Dashboard',
    icon: LayoutDashboard,
    items: [{ id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, hint: 'Live branch overview' }]
  },
  {
    id: 'sales',
    title: 'Sales',
    icon: ShoppingCart,
    items: [
      { id: 'pos', label: 'POS / Billing', icon: ShoppingCart, hint: 'Take orders and collect payment' },
      { id: 'orders', label: 'Orders', icon: ClipboardList, hint: 'Order lifecycle and receipts' },
      { id: 'kitchen', label: 'Kitchen Display', icon: ChefHat, hint: 'Ticket board for the kitchen' },
      { id: 'delivery', label: 'Delivery', icon: Bike, hint: 'Rider assignment and status' }
    ]
  },
  {
    id: 'dining',
    title: 'Guests & Floor',
    icon: UtensilsCrossed,
    items: [
      { id: 'tables', label: 'Tables', icon: Table2, hint: 'Floor plan and seating' },
      { id: 'reservations', label: 'Reservations', icon: CalendarDays, hint: 'Advance table bookings' },
      { id: 'customers', label: 'Customers', icon: Users, hint: 'Guest profiles and loyalty' }
    ]
  },
  {
    id: 'menu',
    title: 'Menu',
    icon: BookOpen,
    items: [
      { id: 'menu', label: 'Menu Items', icon: BookOpen, hint: 'Products, prices and visibility' },
      { id: 'categories', label: 'Categories', icon: Grid2X2, hint: 'Menu sections and ordering' },
      { id: 'recipes', label: 'Recipes', icon: Package, hint: 'Ingredients used per item' },
      { id: 'discounts', label: 'Coupons & Offers', icon: Sparkles, hint: 'Promo codes' },
      { id: 'qr', label: 'QR Menu', icon: QrCode, hint: 'Table QR codes and guest ordering' }
    ]
  },
  {
    id: 'stock',
    title: 'Stock & Suppliers',
    icon: Boxes,
    items: [
      { id: 'inventory', label: 'Inventory', icon: Boxes, hint: 'Stock levels and movements' },
      { id: 'suppliers', label: 'Suppliers', icon: BriefcaseBusiness, hint: 'Vendors and payables' },
      { id: 'purchases', label: 'Purchases', icon: ShoppingBag, hint: 'Goods received notes' }
    ]
  },
  {
    id: 'team',
    title: 'Team',
    icon: Users,
    items: [
      { id: 'employees', label: 'Employees', icon: Users, hint: 'Staff directory and shifts' },
      { id: 'attendance', label: 'Attendance', icon: CalendarDays, hint: 'Daily check-in register' },
      { id: 'payroll', label: 'Payroll', icon: CircleDollarSign, hint: 'Monthly salary runs' }
    ]
  },
  {
    id: 'finance',
    title: 'Finance',
    icon: Wallet,
    items: [
      { id: 'expenses', label: 'Expenses', icon: Wallet, hint: 'Operating cost ledger' },
      { id: 'accounting', label: 'Accounting', icon: BarChart3, hint: 'Cash, payments and ledger' },
      { id: 'dues', label: 'Customer Due', icon: CreditCard, hint: 'Receivables collection' },
      { id: 'reports', label: 'Sales Reports', icon: BarChart3, hint: 'Revenue analytics' },
      { id: 'profit', label: 'Profit & Loss', icon: Activity, hint: 'Margin and cost breakdown' }
    ]
  },
  {
    id: 'setup',
    title: 'Setup',
    icon: Settings,
    items: [
      { id: 'settings', label: 'Settings', icon: Settings, hint: 'Branch profile, currency and tax' },
      { id: 'roles', label: 'Roles & Access', icon: ShieldCheck, hint: 'Role matrix and staff accounts' }
    ]
  }
];

export const allModules: NavItem[] = navTree.flatMap(group => group.items);

export default function Shell({
  view,
  onNavigate,
  children
}: {
  view: string;
  onNavigate: (id: string) => void;
  children: ReactNode;
}) {
  const { data, user, logout, sync, message, toast, dismissToast, money } = useStore();
  const [mobileNav, setMobileNav] = useState(false);
  const [query, setQuery] = useState('');
  const [profileOpen, setProfileOpen] = useState(false);
  const [alertsOpen, setAlertsOpen] = useState(false);

  const scopes = rolePermissions.find(entry => entry.role === user?.role)?.scopes ?? allModules.map(item => item.id);
  const visibleTree = useMemo(
    () => navTree.map(group => ({ ...group, items: group.items.filter(item => scopes.includes(item.id)) })).filter(group => group.items.length > 0),
    [scopes.join('|')] // eslint-disable-line react-hooks/exhaustive-deps
  );
  const visibleModules = visibleTree.flatMap(group => group.items);

  const activeGroupId = navTree.find(group => group.items.some(item => item.id === view))?.id ?? 'overview';
  const [open, setOpen] = useState<Record<string, boolean>>({ [activeGroupId]: true });
  useEffect(() => {
    setOpen(current => (current[activeGroupId] ? current : { ...current, [activeGroupId]: true }));
  }, [activeGroupId]);

  const lowStock = data.inventory.filter(item => item.stock <= item.reorderLevel);
  const activeLabel = allModules.find(item => item.id === view)?.label ?? 'Dashboard';
  const held = data.orders.filter(order => order.number === 'HOLD');
  const openOrders = data.orders.filter(order => !['Completed', 'Cancelled'].includes(order.status) && order.number !== 'HOLD');
  const newGuestOrders = openOrders.filter(order => order.id.startsWith('qr-') && order.status === 'Pending');
  const todaySales = data.orders
    .filter(order => order.number !== 'HOLD' && order.status !== 'Cancelled' && isToday(order.createdAt))
    .reduce((sum, order) => sum + order.total, 0);

  const results = useMemo(() => {
    const term = query.trim().toLowerCase();
    if (!term) return { modules: [], products: [] };
    return {
      modules: visibleModules.filter(item => item.label.toLowerCase().includes(term) || item.id.includes(term)).slice(0, 5),
      products: data.products.filter(item => item.name.toLowerCase().includes(term)).slice(0, 4)
    };
  }, [query, data.products, visibleModules]);

  const go = (id: string) => {
    onNavigate(id);
    setMobileNav(false);
    setProfileOpen(false);
    setAlertsOpen(false);
    setQuery('');
  };

  const badgeFor = (id: string) => {
    if (id === 'kitchen') return openOrders.filter(order => ['Pending', 'Accepted', 'Preparing'].includes(order.status)).length;
    if (id === 'orders') return openOrders.length;
    if (id === 'pos') return held.length;
    return 0;
  };

  const groupBadge = (group: NavGroup) => group.items.reduce((sum, item) => sum + (item.id === 'orders' ? 0 : badgeFor(item.id)), 0);

  const syncLabel =
    sync === 'saving' ? 'Saving…' : sync === 'saved' ? 'Saved' : sync === 'error' ? 'Save failed' : sync === 'offline' ? 'Offline mode' : 'Connected';

  const brandName = data.settings.restaurantName || 'Restaurant';

  return (
    <div className="min-h-screen bg-page text-ink">
      <div className="flex min-h-screen">
        <aside
          className={`fixed inset-y-0 left-0 z-40 flex w-[264px] flex-col border-r border-line bg-surface transition-transform duration-200 lg:sticky lg:top-0 lg:h-screen lg:translate-x-0 ${
            mobileNav ? 'translate-x-0' : '-translate-x-full'
          }`}
        >
          <div className="flex h-[68px] shrink-0 items-center gap-3 px-4">
            <div className="grid h-10 w-10 place-items-center rounded-xl bg-ink font-serif text-xl font-bold text-white">
              {brandName.slice(0, 1).toUpperCase()}
            </div>
            <div className="min-w-0">
              <div className="truncate font-serif text-[17px] font-bold tracking-wide text-ink">{brandName}</div>
              <div className="text-[9px] font-semibold uppercase tracking-[.24em] text-mute2">{data.settings.branchCode} · POS</div>
            </div>
            <button onClick={() => setMobileNav(false)} className="ml-auto text-mute2 lg:hidden" aria-label="Close menu">
              <X size={18} />
            </button>
          </div>

          <div className="mx-3 mb-2 flex items-center gap-2.5 rounded-xl border border-line bg-sunken p-2.5">
            <div className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-ink text-[12px] font-bold text-white">
              {(user?.displayName || 'A').slice(0, 1).toUpperCase()}
            </div>
            <div className="min-w-0 flex-1">
              <div className="truncate text-[12px] font-semibold text-ink">{user?.displayName || 'Admin'}</div>
              <div className="truncate text-[10px] capitalize text-mute2">{user?.role || 'owner'} access</div>
            </div>
            <span className="h-2 w-2 shrink-0 rounded-full bg-emerald-500" />
          </div>

          <nav className="custom-scrollbar flex-1 space-y-1 overflow-y-auto px-2.5 py-2">
            {visibleTree.map(group => {
              const Icon = group.icon;
              const single = group.items.length === 1;
              const groupActive = group.id === activeGroupId;
              const expanded = Boolean(open[group.id]);

              if (single) {
                const item = group.items[0];
                const active = view === item.id;
                const count = badgeFor(item.id);
                return (
                  <button key={group.id} onClick={() => go(item.id)} title={item.hint} className={`nav-item ${active ? 'nav-active' : ''}`}>
                    <Icon size={16} strokeWidth={1.8} />
                    <span className="flex-1 truncate text-left">{item.label}</span>
                    {count > 0 ? <span className="rounded-full bg-accent px-1.5 py-0.5 text-[9.5px] font-bold text-white">{count}</span> : null}
                  </button>
                );
              }

              const count = groupBadge(group);
              return (
                <div key={group.id}>
                  <button
                    onClick={() => setOpen(current => ({ ...current, [group.id]: !expanded }))}
                    aria-expanded={expanded}
                    className={`nav-item ${groupActive && !expanded ? 'bg-sunken text-ink' : ''}`}
                  >
                    <Icon size={16} strokeWidth={1.8} className={groupActive ? 'text-ink' : ''} />
                    <span className={`flex-1 truncate text-left ${groupActive ? 'font-semibold text-ink' : ''}`}>{group.title}</span>
                    {count > 0 && !expanded ? <span className="rounded-full bg-accent px-1.5 py-0.5 text-[9.5px] font-bold text-white">{count}</span> : null}
                    <ChevronDown size={14} className={`shrink-0 text-faint transition-transform ${expanded ? 'rotate-180' : ''}`} />
                  </button>
                  {expanded ? (
                    <div className="ml-[18px] mt-0.5 space-y-0.5 border-l border-line pl-2">
                      {group.items.map(item => {
                        const active = view === item.id;
                        const itemCount = badgeFor(item.id);
                        return (
                          <button key={item.id} onClick={() => go(item.id)} title={item.hint} className={`nav-sub ${active ? 'nav-sub-active' : ''}`}>
                            <span className="flex-1 truncate text-left">{item.label}</span>
                            {itemCount > 0 ? <span className="rounded-full bg-ink px-1.5 py-0.5 text-[9.5px] font-bold text-white">{itemCount}</span> : null}
                          </button>
                        );
                      })}
                    </div>
                  ) : null}
                </div>
              );
            })}
          </nav>

          <div className="shrink-0 border-t border-line p-2.5">
            <div className="rounded-xl bg-ink p-3 text-white">
              <div className="text-[9.5px] font-semibold uppercase tracking-[.18em] text-white/60">Today</div>
              <div className="mt-0.5 font-serif text-[20px] leading-tight">{money(todaySales)}</div>
              <div className="mt-0.5 text-[10.5px] text-white/60">
                {openOrders.length} open order{openOrders.length === 1 ? '' : 's'}
              </div>
            </div>
            <button
              onClick={logout}
              className="mt-1.5 flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-[11.5px] text-mute2 transition hover:bg-sunken hover:text-ink"
            >
              <LogOut size={14} /> Sign out
            </button>
          </div>
        </aside>

        {mobileNav ? (
          <button aria-label="Close navigation overlay" onClick={() => setMobileNav(false)} className="fixed inset-0 z-30 bg-black/40 lg:hidden" />
        ) : null}

        <div className="flex min-w-0 flex-1 flex-col">
          <header className="sticky top-0 z-20 flex h-[68px] shrink-0 items-center justify-between gap-3 border-b border-line bg-surface/90 px-3 backdrop-blur-xl md:px-5">
            <div className="flex min-w-0 items-center gap-2.5">
              <button onClick={() => setMobileNav(true)} className="rounded-lg p-2 text-mute hover:bg-sunken lg:hidden" aria-label="Open menu">
                <Menu size={19} />
              </button>
              <div className="hidden items-center gap-2 text-[11.5px] text-mute2 sm:flex">
                <span className="truncate">{data.settings.branchName}</span>
                <span>/</span>
                <span className="whitespace-nowrap font-semibold text-ink">{activeLabel}</span>
              </div>
              <div className="truncate text-[13px] font-semibold text-ink sm:hidden">{activeLabel}</div>
            </div>

            <div className="flex items-center gap-1.5 md:gap-2.5">
              <div className="relative hidden md:block">
                <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-mute2" />
                <input
                  value={query}
                  onChange={event => setQuery(event.target.value)}
                  placeholder="Find screen or menu item…"
                  className="w-[230px] rounded-lg border border-line bg-sunken py-1.5 pl-8 pr-2 text-[11.5px] text-ink placeholder:text-faint outline-none focus:border-ink focus:bg-surface"
                />
                {query ? (
                  <div className="absolute right-0 top-[calc(100%+6px)] w-[300px] overflow-hidden rounded-xl border border-line bg-surface shadow-pop">
                    {results.modules.length === 0 && results.products.length === 0 ? (
                      <div className="px-3 py-3 text-[11.5px] text-mute2">No matches for “{query}”.</div>
                    ) : (
                      <div className="max-h-72 overflow-y-auto py-1">
                        {results.modules.map(item => (
                          <button key={item.id} onClick={() => go(item.id)} className="flex w-full items-center gap-2.5 px-3 py-2 text-left text-[11.5px] text-ink2 hover:bg-sunken">
                            <item.icon size={14} className="text-ink" /> {item.label}
                          </button>
                        ))}
                        {results.products.map(product => (
                          <button key={product.id} onClick={() => go('menu')} className="flex w-full items-center justify-between gap-2.5 px-3 py-2 text-left text-[11.5px] text-ink2 hover:bg-sunken">
                            <span className="truncate">{product.name}</span>
                            <span className="shrink-0 text-[10px] text-mute2">{money(product.price)}</span>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                ) : null}
              </div>

              <button
                onClick={() => go('pos')}
                className="hidden rounded-lg bg-ink px-3 py-1.5 text-[11.5px] font-semibold text-white transition hover:bg-ink2 sm:block"
              >
                + New sale
              </button>

              <div className="relative">
                <button onClick={() => setAlertsOpen(open => !open)} className="relative rounded-lg p-2 text-mute transition hover:bg-sunken" aria-label="Notifications">
                  <Bell size={17} />
                  {lowStock.length > 0 || openOrders.length > 0 ? (
                    <span className={`absolute right-1.5 top-1.5 h-2 w-2 rounded-full ${newGuestOrders.length > 0 ? 'bg-rose-500' : 'bg-accent'}`} />
                  ) : null}
                </button>
                {alertsOpen ? (
                  <div className="absolute right-0 top-[calc(100%+6px)] w-[300px] overflow-hidden rounded-xl border border-line bg-surface shadow-pop">
                    <div className="border-b border-line px-3 py-2 text-[10px] font-semibold uppercase tracking-[.16em] text-mute2">Operational alerts</div>
                    <div className="max-h-72 space-y-1 overflow-y-auto p-1.5">
                      {newGuestOrders.slice(0, 3).map(order => (
                        <button key={order.id} onClick={() => go('orders')} className="w-full rounded-lg bg-accent/10 px-2.5 py-2 text-left hover:bg-accent/15">
                          <div className="text-[11.5px] font-semibold text-ink">New QR order #{order.number}</div>
                          <div className="text-[10px] text-mute2">
                            {order.customerName} · {money(order.total)}
                          </div>
                        </button>
                      ))}
                      {lowStock.slice(0, 4).map(item => (
                        <button key={item.id} onClick={() => go('inventory')} className="w-full rounded-lg px-2.5 py-2 text-left hover:bg-sunken">
                          <div className="text-[11.5px] font-medium text-amber-800">{item.name} low stock</div>
                          <div className="text-[10px] text-mute2">
                            {item.stock} {item.unit} left · reorder at {item.reorderLevel}
                          </div>
                        </button>
                      ))}
                      {openOrders.filter(order => !newGuestOrders.includes(order)).slice(0, 3).map(order => (
                        <button key={order.id} onClick={() => go('orders')} className="w-full rounded-lg px-2.5 py-2 text-left hover:bg-sunken">
                          <div className="text-[11.5px] font-medium text-ink">
                            #{order.number} · {order.status}
                          </div>
                          <div className="text-[10px] text-mute2">
                            {order.customerName} · {money(order.total)}
                          </div>
                        </button>
                      ))}
                      {lowStock.length === 0 && openOrders.length === 0 ? <div className="px-2.5 py-4 text-center text-[11px] text-mute2">Everything is on track.</div> : null}
                    </div>
                  </div>
                ) : null}
              </div>

              <div
                className={`hidden items-center gap-1.5 rounded-lg border px-2 py-1 text-[10px] font-medium sm:flex ${
                  sync === 'error'
                    ? 'border-rose-300 bg-rose-50 text-rose-700'
                    : sync === 'offline'
                      ? 'border-amber-300 bg-amber-50 text-amber-800'
                      : 'border-line bg-sunken text-mute'
                }`}
                title={message || syncLabel}
              >
                {sync === 'offline' ? <CloudOff size={11} /> : sync === 'saving' ? <Loader2 size={11} className="animate-spin" /> : <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />}
                {syncLabel}
              </div>

              <div className="relative">
                <button
                  onClick={() => setProfileOpen(open => !open)}
                  className="flex items-center gap-1.5 rounded-lg border border-line px-2 py-1.5 text-[11px] text-ink2 hover:bg-sunken"
                >
                  <span className="grid h-6 w-6 place-items-center rounded-full bg-ink text-[10px] font-bold text-white">
                    {(user?.displayName || 'A').slice(0, 1).toUpperCase()}
                  </span>
                  <span className="hidden max-w-[92px] truncate sm:block">{user?.displayName || 'Admin'}</span>
                  <ChevronDown size={13} className="text-mute2" />
                </button>
                {profileOpen ? (
                  <div className="absolute right-0 top-[calc(100%+6px)] w-[228px] overflow-hidden rounded-xl border border-line bg-surface p-2 shadow-pop">
                    <div className="rounded-lg bg-sunken px-2.5 py-2">
                      <div className="truncate text-[12px] font-semibold text-ink">{user?.displayName || 'Admin'}</div>
                      <div className="truncate text-[10px] text-mute2">{user?.email || 'offline@local'}</div>
                      <div className="mt-1 inline-flex rounded-full bg-ink px-1.5 py-0.5 text-[9px] uppercase tracking-wider text-white">{user?.role || 'owner'}</div>
                    </div>
                    <button onClick={() => go('settings')} className="mt-1 flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-[11.5px] text-ink2 hover:bg-sunken">
                      <Settings size={13} /> Branch settings
                    </button>
                    <button onClick={() => go('roles')} className="flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-[11.5px] text-ink2 hover:bg-sunken">
                      <ShieldCheck size={13} /> Roles & access
                    </button>
                    <button onClick={logout} className="flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-[11.5px] text-rose-700 hover:bg-rose-50">
                      <LogOut size={13} /> Sign out
                    </button>
                  </div>
                ) : null}
              </div>
            </div>
          </header>

          <main className="mx-auto w-full max-w-[1560px] flex-1 px-3 py-4 md:px-6 md:py-6">
            {message ? (
              <div className="mb-4 flex items-start gap-2 rounded-xl border border-amber-300 bg-amber-50 px-3 py-2 text-[11.5px] text-amber-900">
                <CloudOff size={14} className="mt-0.5 shrink-0" />
                <span className="flex-1">{message}</span>
              </div>
            ) : null}
            <div key={view} className="rise">
              {children}
            </div>
            <footer className="mt-6 flex flex-wrap items-center justify-between gap-2 border-t border-line pt-3 text-[10px] text-faint">
              <span>
                {data.settings.restaurantName} · {data.settings.branchName}
              </span>
              <span>{data.settings.receiptFooter}</span>
            </footer>
          </main>
        </div>
      </div>

      {toast ? (
        <button
          onClick={dismissToast}
          className="rise fixed bottom-4 right-4 z-[70] flex max-w-sm items-start gap-2 rounded-xl bg-ink px-3.5 py-2.5 text-left text-[11.5px] text-white shadow-pop"
        >
          <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-emerald-400" />
          <span>{toast}</span>
        </button>
      ) : null}
    </div>
  );
}
