const token = name => `rgb(var(--c-${name}) / <alpha-value>)`;

export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['"DM Sans"', 'Inter', '"Segoe UI"', 'system-ui', 'sans-serif'],
        serif: ['"Playfair Display"', 'Georgia', 'serif']
      },
      colors: {
        // One monochrome palette (white surfaces, black ink) — values live in src/index.css
        page: token('page'),
        surface: token('surface'),
        sunken: token('sunken'),
        line: token('line'),
        line2: token('line2'),
        ink: token('ink'),
        ink2: token('ink2'),
        mute: token('mute'),
        mute2: token('mute2'),
        faint: token('faint'),
        accent: token('accent')
      },
      boxShadow: {
        soft: '0 1px 2px rgba(16,16,20,.04), 0 12px 32px -16px rgba(16,16,20,.14)',
        card: '0 1px 2px rgba(16,16,20,.04), 0 6px 20px -12px rgba(16,16,20,.10)',
        pop: '0 24px 64px -24px rgba(16,16,20,.35)'
      }
    }
  },
  plugins: []
};
