"use client";

import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from "react";

type Section =
  | "Dashboard"
  | "POS"
  | "Orders"
  | "Products"
  | "Categories"
  | "Purchases"
  | "Expenses"
  | "Reports"
  | "Staff"
  | "Settings";
type PaymentMethod = "Mada" | "Cash";
type Fulfillment = "Dine in" | "Takeaway";
type Product = {
  id: number;
  name: string;
  category: string;
  price: number;
  stock: number;
  description: string;
  image: string;
  badge?: string;
};
type CartLine = { product: Product; quantity: number };
type Order = {
  id: string;
  time: string;
  customer: string;
  items: number;
  total: number;
  payment: PaymentMethod;
  status: "Completed" | "Preparing" | "Ready";
  type: Fulfillment;
};
type Purchase = { id: string; supplier: string; item: string; date: string; total: number; status: string };
type Expense = { id: string; name: string; category: string; date: string; amount: number };
type StaffMember = { id: number; name: string; role: string; status: "On shift" | "Off shift" };
type ModalState =
  | { kind: "product"; product?: Product }
  | { kind: "category" }
  | { kind: "purchase" }
  | { kind: "expense" }
  | { kind: "staff" }
  | { kind: "order"; order: Order }
  | { kind: "checkout" }
  | null;
type FormValues = {
  name: string;
  category: string;
  price: string;
  stock: string;
  description: string;
  supplier: string;
  amount: string;
  role: string;
};

const photo = {
  signature:
    "https://images.pexels.com/photos/20003199/pexels-photo-20003199.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  double:
    "https://images.pexels.com/photos/20722066/pexels-photo-20722066.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  chicken:
    "https://images.pexels.com/photos/20003229/pexels-photo-20003229.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  crispy:
    "https://images.pexels.com/photos/12129480/pexels-photo-12129480.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  loadedFries:
    "https://images.pexels.com/photos/29285461/pexels-photo-29285461.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  fries:
    "https://images.pexels.com/photos/6428247/pexels-photo-6428247.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  shake:
    "https://images.pexels.com/photos/15801003/pexels-photo-15801003.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
};

const initialProducts: Product[] = [
  {
    id: 1,
    name: "The Faye Original",
    category: "Burgers",
    price: 34,
    stock: 24,
    description: "Angus smash · aged cheddar · Faye sauce",
    image: photo.signature,
    badge: "SIGNATURE",
  },
  {
    id: 2,
    name: "Double Truffle",
    category: "Burgers",
    price: 42,
    stock: 18,
    description: "Double smash · truffle aioli · onion",
    image: photo.double,
    badge: "BESTSELLER",
  },
  {
    id: 3,
    name: "Hot Honey Bird",
    category: "Chicken",
    price: 36,
    stock: 15,
    description: "Crispy thigh · hot honey · slaw",
    image: photo.chicken,
  },
  {
    id: 4,
    name: "Classic Crispy",
    category: "Chicken",
    price: 32,
    stock: 21,
    description: "Buttermilk chicken · pickles · ranch",
    image: photo.crispy,
  },
  {
    id: 5,
    name: "Loaded Truffle Fries",
    category: "Sides",
    price: 21,
    stock: 32,
    description: "Parmesan · truffle · chive",
    image: photo.loadedFries,
    badge: "A LITTLE EXTRA",
  },
  {
    id: 6,
    name: "Skin-on Fries",
    category: "Sides",
    price: 14,
    stock: 40,
    description: "Sea salt · house spice",
    image: photo.fries,
  },
  {
    id: 7,
    name: "Date & Vanilla Shake",
    category: "Drinks",
    price: 23,
    stock: 12,
    description: "Medjool date · real vanilla",
    image: photo.shake,
  },
  {
    id: 8,
    name: "Yuzu Fizz",
    category: "Drinks",
    price: 18,
    stock: 28,
    description: "Yuzu · lime · sparkling water",
    image: photo.signature,
  },
];

const initialOrders: Order[] = [
  { id: "#10486", time: "10:42 AM", customer: "Walk-in", items: 2, total: 68, payment: "Mada", status: "Completed", type: "Takeaway" },
  { id: "#10485", time: "10:36 AM", customer: "Walk-in", items: 3, total: 96, payment: "Cash", status: "Preparing", type: "Dine in" },
  { id: "#10484", time: "10:28 AM", customer: "Walk-in", items: 1, total: 42, payment: "Mada", status: "Ready", type: "Takeaway" },
  { id: "#10483", time: "10:17 AM", customer: "Walk-in", items: 4, total: 113, payment: "Mada", status: "Completed", type: "Dine in" },
  { id: "#10482", time: "10:04 AM", customer: "Walk-in", items: 2, total: 57, payment: "Cash", status: "Completed", type: "Takeaway" },
];

const initialPurchases: Purchase[] = [
  { id: "PO-0281", supplier: "Najd Fresh Foods", item: "Angus beef · 18 kg", date: "Today, 9:12 AM", total: 1_260, status: "Received" },
  { id: "PO-0280", supplier: "Green Basket Co.", item: "Produce · 12 crates", date: "Yesterday", total: 485, status: "Received" },
  { id: "PO-0279", supplier: "Gulf Dairy", item: "Dairy & cheese · 8 cases", date: "12 Mar 2025", total: 720, status: "Received" },
];

const initialExpenses: Expense[] = [
  { id: "EX-0194", name: "Packaging supplies", category: "Supplies", date: "Today", amount: 340 },
  { id: "EX-0193", name: "Delivery fuel", category: "Transport", date: "Yesterday", amount: 185 },
  { id: "EX-0192", name: "Kitchen maintenance", category: "Maintenance", date: "12 Mar 2025", amount: 620 },
];

const initialStaff: StaffMember[] = [
  { id: 1, name: "Noor Al-Harbi", role: "Store manager", status: "On shift" },
  { id: 2, name: "Fahad Mansour", role: "Cashier", status: "On shift" },
  { id: 3, name: "Lina Haddad", role: "Kitchen lead", status: "On shift" },
  { id: 4, name: "Omar Nasser", role: "Crew member", status: "Off shift" },
];

const navGroups: { label: string; items: Section[] }[] = [
  { label: "WORKSPACE", items: ["Dashboard", "POS", "Orders"] },
  { label: "MANAGE", items: ["Products", "Categories", "Purchases", "Expenses"] },
  { label: "INSIGHTS", items: ["Reports"] },
];
const allSections: Section[] = ["Dashboard", "POS", "Orders", "Products", "Categories", "Purchases", "Expenses", "Reports", "Staff", "Settings"];
const iconBySection: Record<Section, string> = {
  Dashboard: "overview",
  POS: "pos",
  Orders: "orders",
  Products: "products",
  Categories: "categories",
  Purchases: "purchases",
  Expenses: "expenses",
  Reports: "reports",
  Staff: "staff",
  Settings: "settings",
};

const iconGlyphs: Record<string, ReactNode> = {
  overview: <><rect x="3" y="3" width="8" height="8" rx="1.4" /><rect x="14" y="3" width="7" height="5" rx="1.3" /><rect x="14" y="11" width="7" height="10" rx="1.3" /><rect x="3" y="14" width="8" height="7" rx="1.3" /></>,
  pos: <><path d="M4 7.5h16l-1.3 12H5.3L4 7.5Z" /><path d="M8.5 8V6a3.5 3.5 0 0 1 7 0v2" /><path d="M8 12h.01M16 12h.01" /></>,
  orders: <><rect x="4" y="3" width="16" height="18" rx="2" /><path d="M8 8h8M8 12h8M8 16h5" /></>,
  products: <><path d="m12 3 8 4.4v9.2L12 21l-8-4.4V7.4L12 3Z" /><path d="m4.5 7.7 7.5 4.2 7.5-4.2M12 12v8.5" /></>,
  categories: <><path d="M4 5.5h16M4 12h16M4 18.5h16" /><circle cx="8" cy="5.5" r="2" fill="currentColor" stroke="none" /><circle cx="15" cy="12" r="2" fill="currentColor" stroke="none" /><circle cx="10" cy="18.5" r="2" fill="currentColor" stroke="none" /></>,
  purchases: <><path d="M3.5 7.5h17l-1.3 12H4.8l-1.3-12Z" /><path d="M8 8V6a4 4 0 0 1 8 0v2M8 12h8" /></>,
  expenses: <><path d="M12 3v18M17 7.5c0-1.5-1.8-2.5-4.5-2.5S8 6 8 7.5 9.7 10 12.5 10s4.5 1 4.5 2.5-1.8 2.5-4.5 2.5S8 14 8 12.5" /></>,
  reports: <><path d="M4 19V5M4 19h17" /><path d="m7 15 4-4 3 2 5-6" /><path d="M16 7h3v3" /></>,
  staff: <><circle cx="9" cy="8" r="3.3" /><path d="M3.5 20a5.5 5.5 0 0 1 11 0M16 5.2a3.3 3.3 0 0 1 0 6.3M17.5 15a4.8 4.8 0 0 1 3 4.5" /></>,
  settings: <><circle cx="12" cy="12" r="3" /><path d="m19.4 15 .1.1 1.4 1.1-1.4 2.4-1.8-.6a7.7 7.7 0 0 1-1.8 1l-.4 1.9h-2.8l-.4-1.9a7.7 7.7 0 0 1-1.8-1l-1.8.6-1.4-2.4 1.4-1.1a7.7 7.7 0 0 1 0-2l-1.4-1.1 1.4-2.4 1.8.6a7.7 7.7 0 0 1 1.8-1l.4-1.9h2.8l.4 1.9a7.7 7.7 0 0 1 1.8 1l1.8-.6 1.4 2.4-1.4 1.1a7.7 7.7 0 0 1 0 2Z" transform="translate(-1 -1) scale(1.08)" /></>,
  search: <><circle cx="10.8" cy="10.8" r="6.8" /><path d="m16 16 4.5 4.5" /></>,
  chevronDown: <path d="m6 9 6 6 6-6" />,
  chevronRight: <path d="m9 18 6-6-6-6" />,
  plus: <path d="M12 5v14M5 12h14" />,
  minus: <path d="M5 12h14" />,
  close: <path d="m6 6 12 12M18 6 6 18" />,
  arrow: <><path d="M4 12h15" /><path d="m13 5 7 7-7 7" /></>,
  back: <><path d="M20 12H5" /><path d="m11 18-6-6 6-6" /></>,
  cart: <><path d="M3 4h2l2.3 11.2a2 2 0 0 0 2 1.6h8.4a2 2 0 0 0 1.9-1.5L21 8H6" /><circle cx="9" cy="20" r="1" /><circle cx="18" cy="20" r="1" /></>,
  clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3.5 2" /></>,
  calendar: <><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M7 3v4M17 3v4M3 10h18" /></>,
  trend: <><path d="m4 16 5-5 4 3 7-8" /><path d="M15 6h5v5" /></>,
  dots: <><circle cx="5" cy="12" r="1" fill="currentColor" /><circle cx="12" cy="12" r="1" fill="currentColor" /><circle cx="19" cy="12" r="1" fill="currentColor" /></>,
  edit: <><path d="m15 5 4 4M4 20l4.2-.8L19 8.4a2.1 2.1 0 0 0-3-3L5.2 16.2 4 20Z" /></>,
  download: <><path d="M12 3v12M7 10l5 5 5-5M4 20h16" /></>,
  filter: <><path d="M4 6h16M7 12h10M10 18h4" /><circle cx="8" cy="6" r="1.4" fill="currentColor" /><circle cx="15" cy="12" r="1.4" fill="currentColor" /></>,
  check: <path d="m5 12 4.5 4.5L19 7" />,
  receipt: <><path d="M5 3.5 7 5l2-1.5L11 5l2-1.5L15 5l2-1.5 2 1.5v17l-2-1.5-2 1.5-2-1.5L11 22l-2-1.5L7 22l-2-1.5v-17Z" /><path d="M8 9h8M8 13h8M8 17h4" /></>,
  card: <><rect x="3" y="5" width="18" height="14" rx="2" /><path d="M3 10h18M7 15h3" /></>,
  cash: <><rect x="3" y="6" width="18" height="13" rx="2" /><circle cx="12" cy="12.5" r="2.5" /><path d="M7 9h.01M17 16h.01" /></>,
  truck: <><path d="M3 5h11v12H3zM14 9h4l3 3v5h-7z" /><circle cx="7" cy="19" r="1.5" /><circle cx="18" cy="19" r="1.5" /></>,
  flame: <><path d="M12 22c4.2 0 7-3 7-7.1 0-3.3-1.8-5.4-4.2-7.8.1 2.2-1.1 3.4-2.1 4.1C12.2 7.1 10 4.6 7.6 3 8.2 7.2 5 9.7 5 14.6 5 18.9 8 22 12 22Z" /><path d="M12 22c-1.6-1.1-2.2-2.3-2.1-3.7.1-1.4.9-2.5 2.1-3.4 1.5 1.5 2.2 2.8 2.2 4.1 0 1.3-.8 2.3-2.2 3Z" /></>,
  spark: <><path d="m12 3 1.5 6.5L20 11l-6.5 1.5L12 19l-1.5-6.5L4 11l6.5-1.5L12 3Z" /><path d="m19 16 .7 2.3L22 19l-2.3.7L19 22l-.7-2.3L16 19l2.3-.7L19 16Z" /></>,
  more: <><circle cx="5" cy="12" r="1" fill="currentColor" /><circle cx="12" cy="12" r="1" fill="currentColor" /><circle cx="19" cy="12" r="1" fill="currentColor" /></>,
  circle: <circle cx="12" cy="12" r="8" />,
};

function Icon({ name, size = 18, className = "" }: { name: string; size?: number; className?: string }) {
  return (
    <svg
      aria-hidden="true"
      className={className}
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {iconGlyphs[name] ?? <circle cx="12" cy="12" r="8" />}
    </svg>
  );
}

function money(amount: number) {
  const formatted = new Intl.NumberFormat("en-SA", { maximumFractionDigits: 2, minimumFractionDigits: 0 }).format(amount);
  return `SAR ${formatted}`;
}

function initials(name: string) {
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0])
    .join("")
    .toUpperCase();
}

function StatusBadge({ status }: { status: string }) {
  const slug = status.toLowerCase().replaceAll(" ", "-");
  return <span className={`status-badge status-${slug}`}><span className="status-dot" />{status}</span>;
}

function blankForm(category = "Burgers"): FormValues {
  return { name: "", category, price: "", stock: "", description: "", supplier: "", amount: "", role: "" };
}

export default function POSApp() {
  const [activeSection, setActiveSection] = useState<Section>("POS");
  const [categories, setCategories] = useState(["Burgers", "Chicken", "Sides", "Drinks"]);
  const [products, setProducts] = useState<Product[]>(initialProducts);
  const [cart, setCart] = useState<CartLine[]>([]);
  const [orders, setOrders] = useState<Order[]>(initialOrders);
  const [purchases, setPurchases] = useState<Purchase[]>(initialPurchases);
  const [expenses, setExpenses] = useState<Expense[]>(initialExpenses);
  const [staff, setStaff] = useState<StaffMember[]>(initialStaff);
  const [activeCategory, setActiveCategory] = useState("All");
  const [productSearch, setProductSearch] = useState("");
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>("Mada");
  const [fulfillment, setFulfillment] = useState<Fulfillment>("Takeaway");
  const [ordersFilter, setOrdersFilter] = useState("All orders");
  const [modal, setModal] = useState<ModalState>(null);
  const [form, setForm] = useState<FormValues>(blankForm());
  const [paidOrder, setPaidOrder] = useState<Order | null>(null);
  const [mobileCartOpen, setMobileCartOpen] = useState(false);
  const [mobileMoreOpen, setMobileMoreOpen] = useState(false);
  const [toast, setToast] = useState("");
  const [todaySales, setTodaySales] = useState(12_480);
  const [todayOrders, setTodayOrders] = useState(186);
  const [settings, setSettings] = useState({ receipt: true, sound: false, compact: false });

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(""), 2700);
    return () => window.clearTimeout(timer);
  }, [toast]);

  const cartCount = cart.reduce((sum, line) => sum + line.quantity, 0);
  const cartTotal = cart.reduce((sum, line) => sum + line.product.price * line.quantity, 0);
  const filteredProducts = useMemo(() => {
    const normalized = productSearch.trim().toLowerCase();
    return products.filter((product) => {
      const matchesCategory = activeCategory === "All" || product.category === activeCategory;
      const matchesSearch = !normalized || `${product.name} ${product.category} ${product.description}`.toLowerCase().includes(normalized);
      return matchesCategory && matchesSearch;
    });
  }, [activeCategory, productSearch, products]);

  const notify = (message: string) => setToast(message);

  const selectSection = (section: Section) => {
    setActiveSection(section);
    setMobileMoreOpen(false);
    setMobileCartOpen(false);
    setProductSearch("");
  };

  const addToCart = (product: Product) => {
    setCart((current) => {
      const existing = current.find((line) => line.product.id === product.id);
      if (existing) {
        return current.map((line) => line.product.id === product.id ? { ...line, quantity: line.quantity + 1 } : line);
      }
      return [...current, { product, quantity: 1 }];
    });
  };

  const changeQuantity = (productId: number, change: number) => {
    setCart((current) => current
      .map((line) => line.product.id === productId ? { ...line, quantity: line.quantity + change } : line)
      .filter((line) => line.quantity > 0));
  };

  const openProductModal = (product?: Product) => {
    setForm(product
      ? { name: product.name, category: product.category, price: String(product.price), stock: String(product.stock), description: product.description, supplier: "", amount: "", role: "" }
      : blankForm(categories[0] ?? "Burgers"));
    setModal({ kind: "product", product });
  };

  const openModal = (kind: "category" | "purchase" | "expense" | "staff") => {
    setForm(blankForm(categories[0] ?? "Burgers"));
    setModal({ kind });
  };

  const closeModal = () => {
    setModal(null);
    setPaidOrder(null);
  };

  const updateForm = (field: keyof FormValues, value: string) => setForm((current) => ({ ...current, [field]: value }));

  const saveForm = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!modal) return;
    const cleanName = form.name.trim();
    if (!cleanName) return;

    if (modal.kind === "product") {
      const nextProduct: Product = {
        id: modal.product?.id ?? Date.now(),
        name: cleanName,
        category: form.category,
        price: Math.max(0, Number(form.price) || 0),
        stock: Math.max(0, Number(form.stock) || 0),
        description: form.description.trim() || "Made fresh to order",
        image: modal.product?.image ?? photo.signature,
        badge: modal.product?.badge,
      };
      setProducts((current) => modal.product
        ? current.map((product) => product.id === modal.product?.id ? nextProduct : product)
        : [nextProduct, ...current]);
      notify(modal.product ? "Menu item updated" : "Menu item added");
    } else if (modal.kind === "category") {
      if (categories.some((category) => category.toLowerCase() === cleanName.toLowerCase())) {
        notify("That category already exists");
        return;
      }
      setCategories((current) => [...current, cleanName]);
      notify("Category added to the menu");
    } else if (modal.kind === "purchase") {
      const purchase: Purchase = {
        id: `PO-${String(Date.now()).slice(-4)}`,
        supplier: form.supplier.trim() || "Local supplier",
        item: cleanName,
        date: "Today, just now",
        total: Math.max(0, Number(form.amount) || 0),
        status: "Received",
      };
      setPurchases((current) => [purchase, ...current]);
      notify("Purchase recorded");
    } else if (modal.kind === "expense") {
      const expense: Expense = {
        id: `EX-${String(Date.now()).slice(-4)}`,
        name: cleanName,
        category: form.category || "Operations",
        date: "Today, just now",
        amount: Math.max(0, Number(form.amount) || 0),
      };
      setExpenses((current) => [expense, ...current]);
      notify("Expense recorded");
    } else if (modal.kind === "staff") {
      setStaff((current) => [...current, { id: Date.now(), name: cleanName, role: form.role.trim() || "Crew member", status: "Off shift" }]);
      notify("Team member added");
    }
    setModal(null);
  };

  const completePayment = () => {
    if (cart.length === 0) return;
    const order: Order = {
      id: `#${String(Date.now()).slice(-5)}`,
      time: new Intl.DateTimeFormat("en-SA", { hour: "2-digit", minute: "2-digit" }).format(new Date()),
      customer: "Walk-in",
      items: cartCount,
      total: cartTotal,
      payment: paymentMethod,
      status: "Completed",
      type: fulfillment,
    };
    setOrders((current) => [order, ...current]);
    setTodaySales((current) => current + cartTotal);
    setTodayOrders((current) => current + 1);
    setPaidOrder(order);
    setCart([]);
    setMobileCartOpen(false);
  };

  const toggleStaff = (id: number) => {
    setStaff((current) => current.map((person) => person.id === id
      ? { ...person, status: person.status === "On shift" ? "Off shift" : "On shift" }
      : person));
  };

  const exportOrders = () => {
    const rows = [
      ["Order", "Time", "Items", "Type", "Payment", "Status", "Total (SAR)"],
      ...orders.map((order) => [order.id, order.time, String(order.items), order.type, order.payment, order.status, String(order.total)]),
    ];
    const csv = rows.map((row) => row.map((value) => `"${value.replaceAll('"', '""')}"`).join(",")).join("\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
    const link = document.createElement("a");
    link.href = url;
    link.download = "faye-orders.csv";
    link.click();
    URL.revokeObjectURL(url);
    notify("Orders report exported");
  };

  const orderRows = orders.filter((order) => {
    if (ordersFilter === "Completed") return order.status === "Completed";
    if (ordersFilter === "In progress") return order.status !== "Completed";
    return true;
  });

  const renderPOS = () => (
    <section className="pos-screen" aria-label="Point of sale">
      <div className="pos-intro">
        <div>
          <div className="eyebrow-row"><span className="live-dot" /> COUNTER 01 <span className="eyebrow-separator">/</span> OLAYA, RIYADH</div>
          <h1>Good afternoon, Noor<span className="title-period">.</span></h1>
          <p className="intro-subtitle">A good day starts with a good order.</p>
        </div>
        <div className="shift-time"><span className="shift-time-icon"><Icon name="clock" size={16} /></span><span><small>SHIFT OPEN</small><strong>{new Intl.DateTimeFormat("en-SA", { hour: "2-digit", minute: "2-digit" }).format(new Date())}</strong></span></div>
      </div>

      <div className="pos-workspace">
        <div className="catalog-column">
          <div className="catalog-heading">
            <div><p className="eyebrow">MADE TO ORDER</p><h2>The menu <span>{products.length.toString().padStart(2, "0")}</span></h2></div>
            <label className="catalog-search">
              <Icon name="search" size={17} />
              <input aria-label="Search menu" placeholder="Search the menu" value={productSearch} onChange={(event) => setProductSearch(event.target.value)} />
              {productSearch && <button type="button" aria-label="Clear search" onClick={() => setProductSearch("")}><Icon name="close" size={14} /></button>}
            </label>
          </div>
          <div className="category-strip" role="tablist" aria-label="Menu categories">
            {["All", ...categories].map((category) => (
              <button key={category} type="button" role="tab" aria-selected={activeCategory === category} className={`category-tab ${activeCategory === category ? "active" : ""}`} onClick={() => setActiveCategory(category)}>
                {category}<span>{category === "All" ? products.length : products.filter((product) => product.category === category).length}</span>
              </button>
            ))}
          </div>
          {filteredProducts.length ? (
            <div className="product-grid">
              {filteredProducts.map((product) => (
                <button type="button" className="menu-product-card" key={product.id} onClick={() => addToCart(product)} aria-label={`Add ${product.name} for ${money(product.price)}`}>
                  <div className="menu-product-photo">
                    <img src={product.image} alt={product.name} loading="lazy" />
                    {product.badge && <span className="product-ribbon">{product.badge}</span>}
                    <span className="product-add"><Icon name="plus" size={17} /></span>
                  </div>
                  <div className="menu-product-info">
                    <div className="menu-product-name"><h3>{product.name}</h3><span>{money(product.price)}</span></div>
                    <p>{product.description}</p>
                  </div>
                </button>
              ))}
            </div>
          ) : (
            <div className="empty-state menu-empty"><span className="empty-icon"><Icon name="search" size={21} /></span><h3>No menu items found</h3><p>Try another search or choose a different category.</p><button className="text-button" type="button" onClick={() => { setProductSearch(""); setActiveCategory("All"); }}>Clear filters</button></div>
          )}
          <div className="catalog-footnote"><Icon name="spark" size={14} /><span>Prepared fresh, served with intention.</span></div>
        </div>

        <div className={`cart-column ${mobileCartOpen ? "cart-column-open" : ""}`}>
          <button type="button" className="cart-backdrop" aria-label="Close order panel" onClick={() => setMobileCartOpen(false)} />
          <aside className="order-panel" aria-label="Current order">
            <div className="order-panel-header">
              <div><p className="eyebrow">SALE · {String(10482 + orders.length).padStart(5, "0")}</p><h2>Current order</h2></div>
              <button className="close-cart-button" type="button" aria-label="Close cart" onClick={() => setMobileCartOpen(false)}><Icon name="close" size={19} /></button>
              <span className="order-count">{cartCount.toString().padStart(2, "0")}</span>
            </div>
            <div className="service-switch" aria-label="Order type">
              {(["Dine in", "Takeaway"] as Fulfillment[]).map((type) => <button type="button" key={type} className={fulfillment === type ? "selected" : ""} onClick={() => setFulfillment(type)}>{type}</button>)}
            </div>
            {cart.length ? (
              <div className="cart-items-list">
                {cart.map(({ product, quantity }) => (
                  <div className="cart-line" key={product.id}>
                    <img src={product.image} alt="" />
                    <div className="cart-line-copy"><strong>{product.name}</strong><span>{money(product.price)}</span><div className="quantity-control"><button type="button" aria-label={`Remove one ${product.name}`} onClick={() => changeQuantity(product.id, -1)}><Icon name="minus" size={13} /></button><span>{quantity}</span><button type="button" aria-label={`Add one ${product.name}`} onClick={() => changeQuantity(product.id, 1)}><Icon name="plus" size={13} /></button></div></div>
                    <strong className="cart-line-total">{money(product.price * quantity)}</strong>
                  </div>
                ))}
              </div>
            ) : (
              <div className="empty-order"><div className="empty-order-art"><Icon name="receipt" size={25} /></div><h3>Your order, your way.</h3><p>Tap a menu favourite to start something delicious.</p></div>
            )}
            <div className="order-panel-footer">
              <div className="order-subtotal"><span>Subtotal</span><span>{money(cartTotal)}</span></div>
              <div className="order-tax-note"><span>VAT included where applicable</span><span>—</span></div>
              <div className="order-total"><span>Total due</span><strong>{money(cartTotal)}</strong></div>
              <p className="payment-prompt">Choose how they’d like to pay</p>
              <div className="payment-options">
                {(["Mada", "Cash"] as PaymentMethod[]).map((method) => <button type="button" key={method} className={paymentMethod === method ? "selected" : ""} onClick={() => setPaymentMethod(method)}><Icon name={method === "Mada" ? "card" : "cash"} size={17} /><span>{method}</span>{paymentMethod === method && <span className="payment-check"><Icon name="check" size={11} /></span>}</button>)}
              </div>
              <button type="button" className="charge-button" disabled={!cart.length} onClick={() => { setPaidOrder(null); setModal({ kind: "checkout" }); }}><span>Collect payment</span><span>{money(cartTotal)}<Icon name="arrow" size={17} /></span></button>
              <p className="checkout-footnote">Secure checkout <span>·</span> Mada & Cash only</p>
            </div>
          </aside>
        </div>
      </div>
    </section>
  );

  const renderDashboard = () => {
    const averageOrder = todaySales / Math.max(todayOrders, 1);
    const metrics = [
      { label: "NET SALES", value: money(todaySales), delta: "+8.4%", icon: "reports", tone: "sage", caption: "vs. previous day" },
      { label: "ORDERS", value: todayOrders.toLocaleString("en-SA"), delta: "+12.2%", icon: "orders", tone: "sand", caption: "vs. previous day" },
      { label: "AVERAGE ORDER", value: money(averageOrder), delta: "+2.4%", icon: "card", tone: "peach", caption: "vs. previous day" },
      { label: "VOID RATE", value: "0.6%", delta: "−0.3%", icon: "check", tone: "lavender", caption: "within 1% target" },
    ];
    const chartPoints = "0,142 45,131 90,137 135,104 180,116 225,89 270,98 315,73 360,82 405,55 450,65 495,35 540,43 585,22";
    return (
      <section className="section-page dashboard-page">
        <div className="section-heading dashboard-heading">
          <div><p className="eyebrow">{new Intl.DateTimeFormat("en-SA", { weekday: "long", day: "2-digit", month: "long", year: "numeric" }).format(new Date()).toUpperCase()} <span className="eyebrow-separator">/</span> OLAYA</p><h1>Good afternoon, Noor<span className="title-period">.</span></h1><p className="section-lede">Here’s what’s happening at Faye today.</p></div>
          <span className="preview-chip"><span className="live-dot" /> Preview data</span>
        </div>
        <div className="metrics-grid">
          {metrics.map((metric) => <article className="metric-card" key={metric.label}><div className="metric-top"><span>{metric.label}</span><span className={`metric-icon metric-${metric.tone}`}><Icon name={metric.icon} size={17} /></span></div><strong className="metric-value">{metric.value}</strong><div className="metric-foot"><span className="metric-delta"><Icon name="trend" size={13} />{metric.delta}</span><span>{metric.caption}</span></div></article>)}
        </div>
        <div className="dashboard-grid">
          <article className="surface sales-chart-card">
            <div className="card-heading"><div><p className="eyebrow">REVENUE OVERVIEW</p><h2>Today’s rhythm</h2></div><div className="chart-legend"><span /> Net sales <span className="chart-legend-label">· SAR</span></div></div>
            <div className="chart-total"><strong>{money(todaySales)}</strong><span><Icon name="trend" size={13} /> 8.4% <small>vs. yesterday</small></span></div>
            <div className="sales-chart">
              <div className="chart-y-labels"><span>4k</span><span>3k</span><span>2k</span><span>1k</span><span>0</span></div>
              <svg viewBox="0 0 600 170" preserveAspectRatio="none" role="img" aria-label="Sales have trended upward through the day">
                <defs><linearGradient id="salesFill" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stopColor="#829a85" stopOpacity=".28" /><stop offset="100%" stopColor="#829a85" stopOpacity="0" /></linearGradient></defs>
                <path className="chart-gridline" d="M0 18H600M0 54H600M0 90H600M0 126H600M0 162H600" />
                <polygon points={`0,170 ${chartPoints} 585,170`} fill="url(#salesFill)" />
                <polyline points={chartPoints} fill="none" stroke="#466653" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
                <circle cx="495" cy="35" r="4.5" fill="#c8925c" stroke="#fff" strokeWidth="3" />
              </svg>
              <div className="chart-x-labels"><span>8 AM</span><span>10 AM</span><span>12 PM</span><span>2 PM</span><span>4 PM</span><span>6 PM</span></div>
            </div>
          </article>
          <article className="surface spotlight-card">
            <div className="card-heading"><div><p className="eyebrow">GUEST FAVOURITE</p><h2>Made to be loved.</h2></div><span className="spotlight-rank">01</span></div>
            <div className="spotlight-image"><img src={photo.double} alt="Double Truffle burger" /><span className="spotlight-badge"><Icon name="flame" size={13} /> TOP SELLER</span></div>
            <div className="spotlight-copy"><div><h3>Double Truffle</h3><p>Burgers <span>·</span> 48 sold today</p></div><strong>{money(42)}</strong></div>
            <div className="spotlight-bar"><span /></div><div className="spotlight-foot"><span>28% of burger sales</span><span>↑ 6.2%</span></div>
          </article>
        </div>
        <article className="surface recent-card">
          <div className="card-heading recent-heading"><div><p className="eyebrow">THE PASS</p><h2>Recent orders</h2></div><button type="button" className="text-button" onClick={() => selectSection("Orders")}>View all <Icon name="arrow" size={15} /></button></div>
          <div className="recent-order-list">
            {orders.slice(0, 4).map((order) => <button type="button" className="recent-order-row" key={order.id} onClick={() => setModal({ kind: "order", order })}><span className="recent-order-id">{order.id}</span><span className="recent-order-type"><span className="order-type-mark"><Icon name={order.type === "Dine in" ? "pos" : "truck"} size={14} /></span>{order.type}</span><span className="recent-order-time">{order.time}</span><StatusBadge status={order.status} /><strong>{money(order.total)}</strong><Icon name="chevronRight" size={15} className="row-chevron" /></button>)}
          </div>
        </article>
      </section>
    );
  };

  const renderProducts = () => (
    <section className="section-page">
      <div className="section-heading">
        <div><p className="eyebrow">YOUR CRAFT, ON THE MENU</p><h1>Products</h1><p className="section-lede">Keep the menu feeling fresh and irresistible.</p></div>
        <button type="button" className="primary-button" onClick={() => openProductModal()}><Icon name="plus" size={17} /> Add product</button>
      </div>
      <div className="list-toolbar"><label className="list-search"><Icon name="search" size={17} /><input aria-label="Search products" placeholder="Search products" value={productSearch} onChange={(event) => setProductSearch(event.target.value)} /></label><span className="list-count">{products.length} menu items</span></div>
      <div className="surface data-card product-data-card">
        <div className="data-header product-data-header"><span>MENU ITEM</span><span>CATEGORY</span><span>PRICE</span><span>IN STOCK</span><span /></div>
        {products.filter((product) => `${product.name} ${product.category}`.toLowerCase().includes(productSearch.toLowerCase())).map((product) => <div className="data-row product-data-row" key={product.id}>
          <div className="product-cell"><img src={product.image} alt="" /><div><strong>{product.name}</strong><small>{product.description}</small></div></div><span className="soft-tag">{product.category}</span><strong className="data-price">{money(product.price)}</strong><span className={product.stock < 10 ? "stock-low" : "stock-normal"}><i />{product.stock} available</span><button type="button" className="icon-button edit-button" aria-label={`Edit ${product.name}`} onClick={() => openProductModal(product)}><Icon name="edit" size={16} /></button>
        </div>)}
        {!products.length && <div className="empty-state"><h3>Your menu starts here</h3><p>Add your first product to build the POS catalogue.</p><button className="primary-button" type="button" onClick={() => openProductModal()}><Icon name="plus" size={16} /> Add product</button></div>}
      </div>
      <p className="page-note"><Icon name="spark" size={14} /> Changes in this preview stay in the current session.</p>
    </section>
  );

  const renderCategories = () => (
    <section className="section-page">
      <div className="section-heading"><div><p className="eyebrow">A MENU WITH A POINT OF VIEW</p><h1>Categories</h1><p className="section-lede">A little order makes every choice feel easy.</p></div><button type="button" className="primary-button" onClick={() => openModal("category")}><Icon name="plus" size={17} /> Add category</button></div>
      <div className="category-management-grid">
        {categories.map((category, index) => {
          const count = products.filter((product) => product.category === category).length;
          const image = products.find((product) => product.category === category)?.image ?? photo.signature;
          return <article className="category-management-card" key={category}>
            <div className={`category-card-image category-image-${index % 4}`}><img src={image} alt="" /><span className="category-index">0{index + 1}</span><span className="category-card-count">{count.toString().padStart(2, "0")} ITEMS</span></div>
            <div className="category-card-copy"><div><p className="eyebrow">FAYE MENU</p><h2>{category}</h2><span>{count} {count === 1 ? "product" : "products"} in this collection</span></div><button type="button" className="icon-button" aria-label={`Filter POS by ${category}`} onClick={() => { setActiveCategory(category); selectSection("POS"); }}><Icon name="arrow" size={17} /></button></div>
          </article>;
        })}
        <button type="button" className="category-add-card" onClick={() => openModal("category")}><span className="add-category-icon"><Icon name="plus" size={19} /></span><strong>Make room for more.</strong><span>Add a new menu category</span></button>
      </div>
    </section>
  );

  const renderOrders = () => (
    <section className="section-page">
      <div className="section-heading"><div><p className="eyebrow">EVERY ORDER, WELL LOOKED AFTER</p><h1>Orders</h1><p className="section-lede">A clear view of what’s on the pass.</p></div><button type="button" className="outline-button" onClick={exportOrders}><Icon name="download" size={16} /> Export orders</button></div>
      <div className="order-summary-strip"><div><span>Today’s orders</span><strong>{todayOrders.toLocaleString("en-SA")}</strong></div><div><span>Sales today</span><strong>{money(todaySales)}</strong></div><div><span>In progress</span><strong>{orders.filter((order) => order.status !== "Completed").length.toString().padStart(2, "0")}</strong></div><div className="summary-strip-date"><Icon name="calendar" size={16} /> Today · Riyadh time</div></div>
      <div className="list-toolbar order-list-toolbar"><div className="filter-tabs">{["All orders", "In progress", "Completed"].map((filter) => <button key={filter} type="button" className={ordersFilter === filter ? "active" : ""} onClick={() => setOrdersFilter(filter)}>{filter}{filter === "All orders" && <span>{orders.length}</span>}</button>)}</div><span className="list-count">Most recent first</span></div>
      <div className="surface order-data-card"><div className="order-table-header"><span>ORDER</span><span>TYPE</span><span>TIME</span><span>PAYMENT</span><span>STATUS</span><span>TOTAL</span><span /></div>
        {orderRows.length ? orderRows.map((order) => <button type="button" className="order-table-row" key={order.id} onClick={() => setModal({ kind: "order", order })}><strong>{order.id}<small>{order.items} {order.items === 1 ? "item" : "items"} · {order.customer}</small></strong><span className="order-type-cell"><Icon name={order.type === "Dine in" ? "pos" : "truck"} size={15} />{order.type}</span><span>{order.time}</span><span className="payment-cell"><Icon name={order.payment === "Mada" ? "card" : "cash"} size={15} />{order.payment}</span><StatusBadge status={order.status} /><strong className="data-price">{money(order.total)}</strong><Icon className="row-chevron" name="chevronRight" size={15} /></button>) : <div className="empty-state"><h3>No orders in this view</h3><p>New POS orders will appear here.</p></div>}
      </div>
    </section>
  );

  const renderPurchases = () => (
    <section className="section-page">
      <div className="section-heading"><div><p className="eyebrow">BEHIND EVERY GOOD BITE</p><h1>Purchases</h1><p className="section-lede">Track the ingredients and essentials that keep service moving.</p></div><button type="button" className="primary-button" onClick={() => openModal("purchase")}><Icon name="plus" size={17} /> Record purchase</button></div>
      <div className="metrics-grid compact-metrics"><article className="metric-card"><div className="metric-top"><span>THIS MONTH</span><span className="metric-icon metric-sage"><Icon name="purchases" size={17} /></span></div><strong className="metric-value">{money(purchases.reduce((sum, purchase) => sum + purchase.total, 0))}</strong><div className="metric-foot"><span>Across {purchases.length} recorded purchases</span></div></article><article className="metric-card"><div className="metric-top"><span>SUPPLIERS</span><span className="metric-icon metric-sand"><Icon name="truck" size={17} /></span></div><strong className="metric-value">{new Set(purchases.map((purchase) => purchase.supplier)).size.toString().padStart(2, "0")}</strong><div className="metric-foot"><span>Trusted local partners</span></div></article><article className="purchase-note-card"><span className="note-star"><Icon name="spark" size={17} /></span><div><strong>Good ingredients, no shortcuts.</strong><p>Keep supplier notes close and purchasing clear.</p></div></article></div>
      <div className="list-toolbar"><div><h2 className="list-title">Recent purchases</h2><p className="list-subtitle">Your latest supply records</p></div><span className="list-count">{purchases.length} records</span></div>
      <div className="surface purchase-list-card"><div className="purchase-table-header"><span>REFERENCE</span><span>SUPPLIER & ITEM</span><span>DATE</span><span>STATUS</span><span>TOTAL</span></div>{purchases.map((purchase) => <div className="purchase-table-row" key={purchase.id}><strong className="reference-id">{purchase.id}</strong><div className="supplier-cell"><span className="supplier-avatar"><Icon name="truck" size={16} /></span><span><strong>{purchase.supplier}</strong><small>{purchase.item}</small></span></div><span className="table-date">{purchase.date}</span><StatusBadge status={purchase.status} /><strong className="data-price">{money(purchase.total)}</strong></div>)}</div>
    </section>
  );

  const renderExpenses = () => {
    const totalExpenses = expenses.reduce((sum, expense) => sum + expense.amount, 0);
    return (
      <section className="section-page">
        <div className="section-heading"><div><p className="eyebrow">THE SMALL THINGS, ADDED UP</p><h1>Expenses</h1><p className="section-lede">A thoughtful record of the costs behind service.</p></div><button type="button" className="primary-button" onClick={() => openModal("expense")}><Icon name="plus" size={17} /> Add expense</button></div>
        <div className="expense-overview"><div className="expense-total-card"><span className="eyebrow">RECORDED EXPENSES</span><strong>{money(totalExpenses)}</strong><p>{expenses.length} entries · current view</p><div className="expense-total-decoration"><span /><span /><span /><span /><span /><span /><span /></div></div><div className="expense-breakdown-card"><div className="card-heading"><div><p className="eyebrow">BY CATEGORY</p><h2>Where it goes</h2></div><Icon name="reports" size={18} /></div>{["Supplies", "Transport", "Maintenance", "Operations"].map((category, index) => { const amount = expenses.filter((expense) => expense.category === category).reduce((sum, expense) => sum + expense.amount, 0); return <div className="expense-breakdown-row" key={category}><span><i className={`expense-key expense-key-${index}`} />{category}</span><span>{money(amount)}</span></div>; })}</div></div>
        <div className="list-toolbar"><div><h2 className="list-title">Expense log</h2><p className="list-subtitle">Everyday operations, accounted for.</p></div><span className="list-count">{expenses.length} records</span></div>
        <div className="surface expense-list-card"><div className="expense-table-header"><span>REFERENCE</span><span>DESCRIPTION</span><span>CATEGORY</span><span>DATE</span><span>AMOUNT</span></div>{expenses.map((expense) => <div className="expense-table-row" key={expense.id}><strong className="reference-id">{expense.id}</strong><strong className="expense-name"><span className="expense-symbol"><Icon name="expenses" size={16} /></span>{expense.name}</strong><span className="soft-tag">{expense.category}</span><span className="table-date">{expense.date}</span><strong className="data-price">{money(expense.amount)}</strong></div>)}</div>
      </section>
    );
  };

  const renderReports = () => (
    <section className="section-page">
      <div className="section-heading"><div><p className="eyebrow">THE BIG PICTURE, BEAUTIFULLY CLEAR</p><h1>Reports</h1><p className="section-lede">A considered look at how your restaurant is doing.</p></div><button type="button" className="outline-button" onClick={exportOrders}><Icon name="download" size={16} /> Export report</button></div>
      <div className="report-filter-row"><div className="report-period"><Icon name="calendar" size={16} /><span>{new Intl.DateTimeFormat("en-SA", { day: "2-digit", month: "short", year: "numeric" }).format(new Date())} · Today</span><Icon name="chevronDown" size={15} /></div><span className="preview-chip"><span className="live-dot" /> Preview data</span></div>
      <div className="metrics-grid report-metrics"><article className="metric-card"><div className="metric-top"><span>GROSS SALES</span><span className="metric-icon metric-sage"><Icon name="reports" size={17} /></span></div><strong className="metric-value">{money(todaySales)}</strong><div className="metric-foot"><span className="metric-delta"><Icon name="trend" size={13} /> +8.4%</span><span>from yesterday</span></div></article><article className="metric-card"><div className="metric-top"><span>COMPLETED ORDERS</span><span className="metric-icon metric-sand"><Icon name="orders" size={17} /></span></div><strong className="metric-value">{todayOrders.toLocaleString("en-SA")}</strong><div className="metric-foot"><span className="metric-delta"><Icon name="trend" size={13} /> +12.2%</span><span>from yesterday</span></div></article><article className="metric-card"><div className="metric-top"><span>AVERAGE TICKET</span><span className="metric-icon metric-peach"><Icon name="card" size={17} /></span></div><strong className="metric-value">{money(todaySales / Math.max(todayOrders, 1))}</strong><div className="metric-foot"><span>Across all payment types</span></div></article><article className="metric-card"><div className="metric-top"><span>PAYMENT MIX</span><span className="metric-icon metric-lavender"><Icon name="cash" size={17} /></span></div><strong className="metric-value">68% <span className="vs-value">Mada</span></strong><div className="payment-mix-line"><span /><i /></div><div className="metric-foot"><span>32% Cash</span></div></article></div>
      <div className="report-grid"><article className="surface report-chart-card"><div className="card-heading"><div><p className="eyebrow">SALES PERFORMANCE</p><h2>Revenue, by hour</h2></div><span className="chart-legend"><i /> SAR</span></div><div className="report-bars">{[38, 54, 44, 72, 64, 88, 75, 100, 86, 68, 48, 60].map((height, index) => <div className="report-bar-wrap" key={index}><span className={`report-bar ${index === 7 ? "highlight" : ""}`} style={{ height: `${height}%` }} /><small>{["8", "9", "10", "11", "12", "1", "2", "3", "4", "5", "6", "7"][index]}</small></div>)}</div><div className="report-chart-note"><span><i />Sales</span><span>Peak hour <strong>3 PM</strong></span></div></article><article className="surface mix-card"><div className="card-heading"><div><p className="eyebrow">PAYMENT BREAKDOWN</p><h2>Paid, your way.</h2></div></div><div className="payment-donut"><div><strong>100%</strong><span>collected</span></div></div><div className="mix-legend"><div><span><i className="mix-mada" />Mada</span><strong>68% <small>{money(todaySales * .68)}</small></strong></div><div><span><i className="mix-cash" />Cash</span><strong>32% <small>{money(todaySales * .32)}</small></strong></div></div></article></div>
      <p className="page-note"><Icon name="spark" size={14} /> Reports shown here reflect the current preview dataset.</p>
    </section>
  );

  const renderStaff = () => (
    <section className="section-page">
      <div className="section-heading"><div><p className="eyebrow">GOOD PEOPLE MAKE GOOD SERVICE</p><h1>Staff</h1><p className="section-lede">Your team, all in one place.</p></div><button type="button" className="primary-button" onClick={() => openModal("staff")}><Icon name="plus" size={17} /> Add team member</button></div>
      <div className="staff-intro-card"><div className="staff-intro-art"><span>F</span><span>F</span><span>F</span></div><div><span className="eyebrow">OLAYA · COUNTER 01</span><h2>Service is a team sport.</h2><p>{staff.filter((person) => person.status === "On shift").length} team members currently on shift.</p></div><div className="staff-avatars">{staff.filter((person) => person.status === "On shift").slice(0, 4).map((person, index) => <span className={`avatar avatar-${index}`} key={person.id}>{initials(person.name)}</span>)}</div></div>
      <div className="list-toolbar"><div><h2 className="list-title">Your team</h2><p className="list-subtitle">Manage the people who make Faye feel like Faye.</p></div><span className="list-count">{staff.length} people</span></div>
      <div className="staff-grid">{staff.map((person, index) => <article className="surface staff-card" key={person.id}><div className={`staff-avatar-large avatar-${index % 4}`}>{initials(person.name)}</div><div className="staff-card-copy"><h3>{person.name}</h3><p>{person.role}</p><StatusBadge status={person.status} /></div><button type="button" className={`staff-shift-button ${person.status === "On shift" ? "is-on" : ""}`} onClick={() => toggleStaff(person.id)}><span /><span>{person.status === "On shift" ? "On shift" : "Set on shift"}</span></button></article>)}</div>
    </section>
  );

  const renderSettings = () => (
    <section className="section-page">
      <div className="section-heading"><div><p className="eyebrow">THE DETAILS THAT MAKE IT YOURS</p><h1>Settings</h1><p className="section-lede">A few thoughtful preferences for your workspace.</p></div></div>
      <div className="settings-layout"><div className="settings-nav"><span className="settings-nav-active"><Icon name="settings" size={16} />General</span><span><Icon name="receipt" size={16} />Receipts</span><span><Icon name="card" size={16} />Payments</span><span><Icon name="staff" size={16} />Team & access</span></div><div className="settings-content">
        <article className="surface settings-card"><div className="settings-card-heading"><span className="settings-section-icon"><Icon name="overview" size={18} /></span><div><h2>Restaurant details</h2><p>Your store identity and regional preferences.</p></div></div><div className="settings-fields"><label><span>Restaurant name</span><input value="Faye Grill Club" readOnly /></label><label><span>Branch</span><input value="Olaya · Riyadh" readOnly /></label><label><span>Currency</span><div className="settings-value">SAR <small>Saudi riyal · default</small></div></label><label><span>Time zone</span><div className="settings-value">Riyadh (GMT+3) <small>Asia/Riyadh</small></div></label></div></article>
        <article className="surface settings-card"><div className="settings-card-heading"><span className="settings-section-icon"><Icon name="card" size={18} /></span><div><h2>Payment methods</h2><p>Only enabled methods are available at checkout.</p></div></div><div className="settings-method-row"><span className="settings-method-icon mada-wordmark">mada</span><span><strong>Mada</strong><small>Card payments</small></span><span className="enabled-pill"><i />Enabled</span></div><div className="settings-method-row"><span className="settings-method-icon"><Icon name="cash" size={19} /></span><span><strong>Cash</strong><small>Cash at counter</small></span><span className="enabled-pill"><i />Enabled</span></div><p className="settings-footnote">Customer due and credit payments are not available.</p></article>
        <article className="surface settings-card"><div className="settings-card-heading"><span className="settings-section-icon"><Icon name="spark" size={18} /></span><div><h2>Workspace preferences</h2><p>Make the counter feel just right.</p></div></div><div className="preference-row"><span><strong>Print receipt after payment</strong><small>Prepare a receipt for every completed order.</small></span><button type="button" role="switch" aria-checked={settings.receipt} className={`toggle-switch ${settings.receipt ? "on" : ""}`} onClick={() => setSettings((current) => ({ ...current, receipt: !current.receipt }))}><i /></button></div><div className="preference-row"><span><strong>Sound cues</strong><small>Play a subtle sound when a new order is placed.</small></span><button type="button" role="switch" aria-checked={settings.sound} className={`toggle-switch ${settings.sound ? "on" : ""}`} onClick={() => setSettings((current) => ({ ...current, sound: !current.sound }))}><i /></button></div><div className="preference-row"><span><strong>Compact menu cards</strong><small>Show more items on the point-of-sale screen.</small></span><button type="button" role="switch" aria-checked={settings.compact} className={`toggle-switch ${settings.compact ? "on" : ""}`} onClick={() => { setSettings((current) => ({ ...current, compact: !current.compact })); document.documentElement.classList.toggle("compact-menu", !settings.compact); }}><i /></button></div></article>
        <div className="session-note"><span className="live-dot" /><span><strong>UI preview</strong> · Changes are held in this browser session.</span></div>
      </div></div>
    </section>
  );

  const renderSection = () => {
    switch (activeSection) {
      case "POS": return renderPOS();
      case "Dashboard": return renderDashboard();
      case "Orders": return renderOrders();
      case "Products": return renderProducts();
      case "Categories": return renderCategories();
      case "Purchases": return renderPurchases();
      case "Expenses": return renderExpenses();
      case "Reports": return renderReports();
      case "Staff": return renderStaff();
      case "Settings": return renderSettings();
    }
  };

  const modalFormTitle = modal?.kind === "product"
    ? modal.product ? "Edit menu item" : "Add a menu favourite"
    : modal?.kind === "category" ? "Create a category"
      : modal?.kind === "purchase" ? "Record a purchase"
        : modal?.kind === "expense" ? "Add an expense"
          : modal?.kind === "staff" ? "Add a team member" : "";

  return (
    <div className={`app-shell ${settings.compact ? "compact-menu" : ""}`}>
      <aside className="sidebar">
        <div className="brand-lockup"><span className="brand-mark"><span>F</span></span><span className="brand-type"><strong>FAYE</strong><small>GRILL CLUB</small></span></div>
        <button type="button" className="branch-switch" onClick={() => notify("Olaya · Riyadh is your active branch")}><span className="branch-pin"><span /></span><span className="branch-copy"><small>YOUR RESTAURANT</small><strong>Olaya, Riyadh</strong></span><Icon name="chevronDown" size={15} /></button>
        <nav className="sidebar-nav" aria-label="Main navigation">
          {navGroups.map((group) => <div className="nav-group" key={group.label}><span className="nav-group-label">{group.label}</span>{group.items.map((section) => <button key={section} type="button" aria-label={section} aria-current={activeSection === section ? "page" : undefined} className={`nav-link ${activeSection === section ? "active" : ""}`} onClick={() => selectSection(section)}><Icon name={iconBySection[section]} size={18} /><span>{section}</span>{section === "Orders" && <span className="nav-count">{orders.filter((order) => order.status !== "Completed").length}</span>}</button>)}</div>)}
        </nav>
        <div className="sidebar-bottom"><button type="button" aria-label="Staff" aria-current={activeSection === "Staff" ? "page" : undefined} className={`nav-link secondary-nav ${activeSection === "Staff" ? "active" : ""}`} onClick={() => selectSection("Staff")}><Icon name="staff" size={18} /><span>Staff</span></button><button type="button" aria-label="Settings" aria-current={activeSection === "Settings" ? "page" : undefined} className={`nav-link secondary-nav ${activeSection === "Settings" ? "active" : ""}`} onClick={() => selectSection("Settings")}><Icon name="settings" size={18} /><span>Settings</span></button><div className="shift-card"><span className="shift-card-top"><span><i /> SHIFT IN PROGRESS</span><Icon name="dots" size={16} /></span><strong>03<span>h</span> 18<span>m</span></strong><small>Counter 01 <i /> Olaya branch</small></div><div className="sidebar-user"><span className="avatar user-avatar">NA</span><span className="sidebar-user-copy"><strong>Noor Al-Harbi</strong><small>Store manager</small></span><button type="button" aria-label="Show profile" onClick={() => notify("Signed in as Noor Al-Harbi")}><Icon name="dots" size={17} /></button></div></div>
      </aside>

      <div className="app-main">
        <header className="topbar">
          <div className="topbar-context"><div className="mobile-brand-lockup"><span className="brand-mark"><span>F</span></span><strong>FAYE</strong></div><span className="topbar-branch">OLAYA <span>·</span> RIYADH</span><span className="topbar-divider">/</span><span className="topbar-current">{activeSection === "POS" ? "Point of sale" : activeSection}</span></div>
          <div className="topbar-actions"><span className="preview-chip topbar-preview"><span className="preview-dot" /> UI preview</span><span className="topbar-date">{new Intl.DateTimeFormat("en-SA", { weekday: "short", day: "2-digit", month: "short" }).format(new Date())}</span><span className="topbar-action-divider" /><span className="avatar topbar-avatar">NA</span><span className="topbar-user-name">Noor Al-Harbi<small>Manager</small></span></div>
        </header>
        <main className={`main-content ${activeSection === "POS" ? "main-content-pos" : ""}`} key={activeSection}>{renderSection()}</main>
      </div>

      {mobileMoreOpen && <><button type="button" className="mobile-more-scrim" aria-label="Close menu" onClick={() => setMobileMoreOpen(false)} /><div className="mobile-more-sheet"><div className="mobile-sheet-grabber" /><p className="eyebrow">YOUR WORKSPACE</p><h2>Where to next?</h2><div className="mobile-more-grid">{allSections.filter((section) => !["POS", "Dashboard", "Orders"].includes(section)).map((section) => <button type="button" key={section} className={activeSection === section ? "active" : ""} onClick={() => selectSection(section)}><span><Icon name={iconBySection[section]} size={19} /></span>{section}</button>)}</div></div></>}

      {activeSection === "POS" && cartCount > 0 && <button type="button" className="mobile-cart-launch" onClick={() => setMobileCartOpen(true)}><span className="mobile-cart-icon"><Icon name="cart" size={19} /><i>{cartCount}</i></span><span className="mobile-cart-copy"><strong>Review order</strong><small>{cartCount} {cartCount === 1 ? "item" : "items"} · {fulfillment}</small></span><strong className="mobile-cart-total">{money(cartTotal)}<Icon name="arrow" size={16} /></strong></button>}
      <nav className="mobile-bottom-nav" aria-label="Mobile navigation"><button type="button" className={activeSection === "POS" ? "active" : ""} onClick={() => selectSection("POS")}><Icon name="pos" size={19} /><span>Sell</span></button><button type="button" className={activeSection === "Dashboard" ? "active" : ""} onClick={() => selectSection("Dashboard")}><Icon name="overview" size={19} /><span>Overview</span></button><button type="button" className={activeSection === "Orders" ? "active" : ""} onClick={() => selectSection("Orders")}><Icon name="orders" size={19} /><span>Orders</span></button><button type="button" className={mobileMoreOpen ? "active" : ""} onClick={() => setMobileMoreOpen((current) => !current)}><Icon name="more" size={20} /><span>More</span></button></nav>

      {toast && <div className="toast-message"><span className="toast-check"><Icon name="check" size={14} /></span>{toast}</div>}

      {modal && <div className="modal-scrim" onMouseDown={(event) => { if (event.target === event.currentTarget) closeModal(); }}>
        {modal.kind === "checkout" ? (
          <section className="modal-card checkout-modal" role="dialog" aria-modal="true" aria-labelledby="checkout-title">
            <button type="button" className="modal-close" aria-label="Close checkout" onClick={closeModal}><Icon name="close" size={18} /></button>
            {paidOrder ? <div className="payment-success"><span className="success-mark"><Icon name="check" size={28} /></span><p className="eyebrow">PAYMENT RECEIVED</p><h2 id="checkout-title">That’s a good one.</h2><p>{paidOrder.id} · {paidOrder.payment} · {paidOrder.time}</p><div className="success-total">{money(paidOrder.total)}</div><div className="modal-actions success-actions"><button type="button" className="outline-button" onClick={() => { setActiveSection("Orders"); closeModal(); }}>View orders</button><button type="button" className="primary-button" onClick={closeModal}>Start a new order <Icon name="arrow" size={16} /></button></div></div> : <><span className="checkout-modal-icon"><Icon name={paymentMethod === "Mada" ? "card" : "cash"} size={22} /></span><p className="eyebrow">ONE LAST THING</p><h2 id="checkout-title">Collect payment</h2><p className="modal-description">Confirm the amount and payment method with your guest.</p><div className="checkout-method-grid">{(["Mada", "Cash"] as PaymentMethod[]).map((method) => <button type="button" key={method} className={paymentMethod === method ? "selected" : ""} onClick={() => setPaymentMethod(method)}><Icon name={method === "Mada" ? "card" : "cash"} size={18} /><span>{method}</span>{paymentMethod === method && <Icon name="check" size={15} />}</button>)}</div><div className="checkout-amount-row"><span>Amount to collect</span><strong>{money(cartTotal)}</strong></div><p className="checkout-vat-copy">VAT included where applicable · No customer due</p><button type="button" className="charge-button modal-charge" onClick={completePayment}><span>Confirm {paymentMethod} payment</span><span><Icon name="arrow" size={17} /></span></button></>}
          </section>
        ) : modal.kind === "order" ? (
          <section className="modal-card order-detail-modal" role="dialog" aria-modal="true" aria-labelledby="order-detail-title"><button type="button" className="modal-close" aria-label="Close order details" onClick={closeModal}><Icon name="close" size={18} /></button><span className="checkout-modal-icon"><Icon name="receipt" size={21} /></span><p className="eyebrow">ORDER DETAILS</p><h2 id="order-detail-title">{modal.order.id}</h2><div className="detail-status-row"><StatusBadge status={modal.order.status} /><span>{modal.order.time}</span></div><div className="order-detail-list"><div><span>Order type</span><strong>{modal.order.type}</strong></div><div><span>Guest</span><strong>{modal.order.customer}</strong></div><div><span>Items</span><strong>{modal.order.items} {modal.order.items === 1 ? "item" : "items"}</strong></div><div><span>Payment</span><strong>{modal.order.payment}</strong></div></div><div className="checkout-amount-row"><span>Total paid</span><strong>{money(modal.order.total)}</strong></div><button type="button" className="primary-button detail-done" onClick={closeModal}>Done</button></section>
        ) : (
          <section className="modal-card form-modal" role="dialog" aria-modal="true" aria-labelledby="form-modal-title"><button type="button" className="modal-close" aria-label="Close dialog" onClick={closeModal}><Icon name="close" size={18} /></button><span className="form-modal-mark"><Icon name={modal.kind === "product" ? "products" : modal.kind === "category" ? "categories" : modal.kind === "purchase" ? "purchases" : modal.kind === "expense" ? "expenses" : "staff"} size={19} /></span><p className="eyebrow">FAYE · OLAYA</p><h2 id="form-modal-title">{modalFormTitle}</h2><p className="modal-description">{modal.kind === "product" ? "A few details to keep the menu looking its best." : modal.kind === "purchase" ? "Keep your supply records close and clear." : modal.kind === "expense" ? "Capture the cost while it’s fresh." : modal.kind === "staff" ? "Good people make good service." : "Give guests a clearer way to find their favourites."}</p>
            <form className="modal-form" onSubmit={saveForm}>
              {modal.kind === "product" && <><label><span>Product name</span><input autoFocus required value={form.name} onChange={(event) => updateForm("name", event.target.value)} placeholder="e.g. The Faye Original" /></label><label><span>Menu description</span><input value={form.description} onChange={(event) => updateForm("description", event.target.value)} placeholder="A short, delicious description" /></label><div className="form-two-col"><label><span>Category</span><select value={form.category} onChange={(event) => updateForm("category", event.target.value)}>{categories.map((category) => <option key={category}>{category}</option>)}</select></label><label><span>Price · SAR</span><input required type="number" min="0" step="0.5" value={form.price} onChange={(event) => updateForm("price", event.target.value)} placeholder="34" /></label></div><label><span>Available stock</span><input type="number" min="0" step="1" value={form.stock} onChange={(event) => updateForm("stock", event.target.value)} placeholder="24" /></label></>}
              {modal.kind === "category" && <label><span>Category name</span><input autoFocus required value={form.name} onChange={(event) => updateForm("name", event.target.value)} placeholder="e.g. Seasonal specials" /></label>}
              {modal.kind === "purchase" && <><label><span>Item or supply</span><input autoFocus required value={form.name} onChange={(event) => updateForm("name", event.target.value)} placeholder="e.g. Angus beef · 18 kg" /></label><label><span>Supplier</span><input value={form.supplier} onChange={(event) => updateForm("supplier", event.target.value)} placeholder="Supplier name" /></label><label><span>Total · SAR</span><input required type="number" min="0" step="0.01" value={form.amount} onChange={(event) => updateForm("amount", event.target.value)} placeholder="0.00" /></label></>}
              {modal.kind === "expense" && <><label><span>Description</span><input autoFocus required value={form.name} onChange={(event) => updateForm("name", event.target.value)} placeholder="e.g. Packaging supplies" /></label><div className="form-two-col"><label><span>Category</span><select value={form.category} onChange={(event) => updateForm("category", event.target.value)}>{["Supplies", "Transport", "Maintenance", "Operations"].map((category) => <option key={category}>{category}</option>)}</select></label><label><span>Amount · SAR</span><input required type="number" min="0" step="0.01" value={form.amount} onChange={(event) => updateForm("amount", event.target.value)} placeholder="0.00" /></label></div></>}
              {modal.kind === "staff" && <><label><span>Team member name</span><input autoFocus required value={form.name} onChange={(event) => updateForm("name", event.target.value)} placeholder="Full name" /></label><label><span>Role</span><select value={form.role || "Crew member"} onChange={(event) => updateForm("role", event.target.value)}>{["Crew member", "Cashier", "Kitchen lead", "Store manager"].map((role) => <option key={role}>{role}</option>)}</select></label></>}
              <div className="modal-actions"><button type="button" className="outline-button" onClick={closeModal}>Cancel</button><button type="submit" className="primary-button">{modal.kind === "product" && modal.product ? "Save changes" : modal.kind === "product" ? "Add to menu" : modal.kind === "category" ? "Create category" : modal.kind === "purchase" ? "Record purchase" : modal.kind === "expense" ? "Save expense" : "Add to team"}<Icon name="arrow" size={16} /></button></div>
            </form>
          </section>
        )}
      </div>}
    </div>
  );
}
